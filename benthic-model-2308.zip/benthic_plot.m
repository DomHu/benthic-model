figure
subplot(3,3,1)
plot(C1*12/rho_sed, -(0:100), 'b')
hold on
plot(C2*12/rho_sed, -(0:100), 'g')
plot(C*12/rho_sed, -(0:100), 'k')
plot([0,(C01+C02)*12/rho_sed ], [-zbio,-zbio], 'k--')
hold off
xlabel ('TOC (wt%)')
ylabel('Sediment Depth (cm)')
title('Total TOC (wt%)')

subplot(3,3,2)
plot(C11*12/rho_sed, -(0:100), 'b')
hold on
plot(C21*12/rho_sed, -(0:100), 'g')
plot([0,(C01)*12/rho_sed ], [-zbio,-zbio], 'k--')
hold off
xlabel ('TOC (wt%)')
ylabel('Sediment Depth (cm)')
title ('First TOC Fraction (wt%)')

subplot(3,3,3)
plot(C12*12/rho_sed, -(0:100), 'b')
hold on
plot(C22*12/rho_sed, -(0:100), 'g')
plot([0,(C02)*12/rho_sed ], [-zbio,-zbio], 'k--')
hold off
xlabel ('TOC (wt%)')
ylabel('Sediment Depth (cm)')
title ('Second TOC Fraction (wt%)')

subplot(3,3,4)
plot(O2(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,O20], [-zbio,-zbio], 'k--')
hold off
xlabel ('O2 (mol/cm3)')
ylabel('Sediment Depth (cm)')
title ('O2 (mol/cm3)')

subplot(3,3,5)
plot(SO4(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,SO40], [-zbio,-zbio], 'k--')
hold off
%xlim([0 SO40])
xlabel ('SO4 (mol/cm3)')
ylabel('Sediment Depth (cm)')
title ('SO4 (mol/cm3)')

subplot(3,3,6)
plot(NO3(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,NO30], [-zbio,-zbio], 'k--')
hold off
%xlim([0 SO40])
xlabel ('NO3 (mol/cm3)')
ylabel('Sediment Depth (cm)')
title ('NO3 (mol/cm3)')

 subplot(3,3,7)
 plot(H2S(1:1001), -(0:1000)/10, 'b')
 hold on
 plot([0,H2S0], [-zbio,-zbio], 'k--')
 hold off
% %xlim([0 H2S0])
 xlabel ('H2S (mol/cm3)')
 ylabel('Sediment Depth (cm)')
 title ('H2S (mol/cm3)')
 
subplot(3,3,8)
 plot(NH4(1:1001), -(0:1000)/10, 'b')
 hold on
 plot([0,NH40], [-zbio,-zbio], 'k--')
 hold off
% %xlim([0 H2S0])
 xlabel ('NH4 (mol/cm3)')
 ylabel('Sediment Depth (cm)')
 title ('NH4 (mol/cm3)')
 
 subplot(3,3,9)
 plot(PO4(1:1001), -(0:1000)/10, 'b')
 hold on
 plot([0,PO40], [-zbio,-zbio], 'k--')
 hold off
 xlabel ('PO4 (mol/cm3)')
 ylabel('Sediment Depth (cm)')
 title ('PO4 (mol/cm3)')
 
 
 figure;

subplot(1,3,1)
plot(DIC(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,max(DIC)], [-zox,-zox], 'k--')
plot([0,max(DIC)], [-zbio,-zbio], 'r--')
plot([0,max(DIC)], [-zno3,-zno3], 'g--')
plot([0,max(DIC)], [-zso4,-zso4], 'o--')
legend('ALK','zox','zbio','zno3','zso4');
hold off

xlabel ('DIC (mol/cm3)')
ylabel('Sediment Depth (cm)')
title ('DIC (mol/cm3)')
 
 
subplot(1,3,2)
plot(ALK(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,max(ALK)], [-zox,-zox], 'k--')
plot([0,max(ALK)], [-zbio,-zbio], 'r--')
plot([0,max(ALK)], [-zno3,-zno3], 'g--')
plot([0,max(ALK)], [-zso4,-zso4], 'o--')
hold off

xlabel ('ALK (mol/cm3)')
ylabel('Sediment Depth (cm)')
title ('ALK (mol/cm3)')
 
subplot(1,3,3)
plot(pH(1:1001), -(0:1000)/10, 'b')
hold on
plot([0,max(pH)], [-zox,-zox], 'k--')
plot([0,max(pH)], [-zbio,-zbio], 'r--')
plot([0,max(pH)], [-zno3,-zno3], 'g--')
plot([0,max(pH)], [-zso4,-zso4], 'o--')
hold off
%xlim([0 H2S0])
xlabel ('pH')
ylabel('Sediment Depth (cm)')
title ('pH')
