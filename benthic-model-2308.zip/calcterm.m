% j: layer
% ztemp: lower boundary of the layer
% ztemp1: upper boudary of the layer


if (ztemp<=zbio)
     beta(1,j)=-a11;
     beta(2,j)=-b11;
     beta(3,j)=-b11;
     beta(4,j)=-a12;
     beta(5,j)=-b12;
     beta(6,j)=-b12;
     
     term(1,j)=-k1*(reac1)*A11/(Dtemp*beta(1,j)^2+w*beta(1,j)-ktemp);
     term(2,j)=k1*(reac1)*A11/(Dtemp*beta(2,j)^2+w*beta(2,j)-ktemp);
     term(3,j)=-k1*(reac1)*C01/(Dtemp*beta(3,j)^2+w*beta(3,j)-ktemp);
     term(4,j)=-k2*(reac2)*A12/(Dtemp*beta(4,j)^2+w*beta(4,j)-ktemp);
     term(5,j)=k2*(reac2)*A12/(Dtemp*beta(5,j)^2+w*beta(5,j)-ktemp);
     term(6,j)=-k2*(reac2)*C02/(Dtemp*beta(6,j)^2+w*beta(6,j)-ktemp);
     
     sum_term(j)=sum(term(:,j));
     sum_termexp(j,1)=sum(term(:,j).*exp(-beta(:,j).*ztemp));
     sum_termdev(j,1)=sum(-term(:,j).*beta(:,j).*exp(-beta(:,j).*ztemp));
     
     sum_termexp(j,2)=sum(term(:,j).*exp(-beta(:,j).*ztemp1));
     sum_termdev(j,2)=sum(-term(:,j).*beta(:,j).*exp(-beta(:,j).*ztemp1));
else
     beta(1,j)=-a21;
     beta(2,j)=-a22;
    
     term(1,j)=-k1*(reac1)*A21/(Dtemp*beta(1,j)^2+w*beta(1,j)-ktemp);
     term(2,j)=-k2*(reac2)*A22/(Dtemp*beta(2,j)^2+w*beta(2,j)-ktemp);
    
     sum_term(j)=sum(term(:,j));
     sum_termexp(j,1)=sum(term(:,j).*exp(-beta(:,j).*ztemp));
     sum_termdev(j,1)=sum(-term(:,j).*beta(:,j).*exp(-beta(:,j).*ztemp));
     
     sum_termexp(j,2)=sum(term(:,j).*exp(-beta(:,j).*ztemp1));
     sum_termdev(j,2)=sum(-term(:,j).*beta(:,j).*exp(-beta(:,j).*ztemp1));
end
