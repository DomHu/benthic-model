% Solve SO4

%__________________________________________________________________________________________________________________________
%SO4
%transport equation above zNO3:
%                                           dSO4/dt=D*(d^2SO4/dz^2)-w*dSO4/dz
%
%reaction-transport equation below zNO3:
%                                           dSO4/dt=D*(d^2SO4/dz^2)-w*dSO4/dz-sum(ki*SO4Ci*TOC(z))
%__________________________________________________________________________________________________________________________

%__________________________________________________________________________      
% Case 0: zox=zbio=zno3=0
%__________________________________________________________________________

if (zno3==0)
    
%define exponents
bSO41=w/DSO42;

%LAYER 1 reactive terms: Sulfato Reduction (-) 
j=1; ztemp=1; ztemp1=0;
reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DSO42;
calcterm;

BSO41=@(zso4) -((exp(a22*zso4) - 1)*term(2,1) + (exp(a21*zso4) - 1)*term(1,1) + SO40 - satSO4)/(exp(bSO41*zso4) - 1);

sumtermdevzso4=@(zso4)sum(-term(:,1).*beta(:,1).*exp(-beta(:,1).*zso4));

reacf1=MC*k1;
reacf2=MC*k2;

% Flux of CH4 produced under zso4 that is oxidized at zso4; consumming SO4
FSO4=@(zso4)-1/por*(reacf1*A21*exp(a21*zso4)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zso4)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

fun=@(zso4)-por*DSO42*(BSO41(zso4)*bSO41*exp(bSO41*zso4)+sumtermdevzso4(zso4))-FSO4(zso4);    

zso4=fzero(fun,[-1 zinf]);
 
zso4(zso4<0)=0;

%define integration constants and parameters
ASO41 = ((exp(a22*zso4)-exp(bSO41*zso4))*term(2,1)+(exp(a21*zso4)-exp(bSO41*zso4))*term(1,1)+SO40*exp(bSO41*zso4)-satSO4)/(exp(bSO41*zso4)-1);
BSO41=-((exp(a22*zso4)-1)*term(2,1)+(exp(a21*zso4)-1)*term(1,1)+SO40-satSO4)/(exp(bSO41*zso4)-1);

if calcconc==1
    ztemp(1)=zso4; 
    Atemp(1)=ASO41; 
    Btemp(1)=BSO41; 
    atemp(1)=0; 
    btemp(1)=bSO41; 
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DSO41;
    conc0temp=SO40;
    calconc;
    F_SO4=F_temp;
    SO4=conc;
end

else

%__________________________________________________________________________    
% Case 1, subcase 1: zox<zbio<zno3<zso4
%__________________________________________________________________________

if (zox<zbio)
    if (zbio<zno3)
 
%define exponents
bSO41=w/DSO41;
bSO42=w/DSO41;
bSO43=w/DSO42;
bSO44=w/DSO42;

%LAYER 1 reactive terms: /
j=1; ztemp=zox; ztemp1=0;

%LAYER 2 reactive terms: /
j=2; ztemp=zbio; ztemp1=zox;

%LAYER 3 reactive terms: /
j=3; ztemp=zno3; ztemp1=zbio;

%LAYER 4 reactive terms: Sulfato reduction (-)
j=4; ztemp=zno3+1; ztemp1=zno3;

reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DSO42;
calcterm;

sumtermexpzso4=@(zso4) sum(term(:,4).*exp(-beta(:,4).*zso4));
sumtermdevzso4=@(zso4) sum(-term(:,4).*beta(:,4).*exp(-beta(:,4).*zso4));

%flux of H2S to oxic interface (Source of SO4)

reacf1=k1*SO4C;
reacf2=k2*SO4C;

FH2S=@(zso4)-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zso4)*a22...
    +reacf2*A22*exp(a22*zno3)*a21-reacf2*A22*exp(a22*zso4)*a21)/(a21*a22); % MULTIPLY BY 1/POR ????

% Flux of CH4 produced under zso4 that is oxidized at zso4; consumming SO4

reacf1=gammaCH4*k1*MC;
reacf2=gammaCH4*k2*MC;

FSO4=@(zso4)-1/por*(reacf1*A21*exp(a21*zso4)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zso4)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

BSO44=@(zso4)(DSO41*sum_termexp(4, 2)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43*exp(bSO41*zox)*bSO41-DSO41*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43*exp(bSO41*zox)*bSO41-SO40*DSO41*exp(bSO42*zbio)*bSO42*exp(bSO43*zno3)*bSO43*exp(bSO41*zox)*bSO41+DSO41*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*exp(bSO41*zox)*bSO41-DSO41*exp(bSO42*zbio)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*exp(bSO41*zox)*bSO41+DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO43*exp(bSO41*zox)*bSO41-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO43*exp(bSO41*zox)*bSO41+DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43)/(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43);

fun=@(zso4)-por*DSO42*(BSO44(zso4)*bSO44*exp(bSO44*zso4)+sumtermdevzso4(zso4))-FSO4(zso4);  

zso4=fzero(fun,[-1 zinf]);

zso4(zso4<0)=0;

ASO41 = (-DSO41*DSO42*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sum_termexp(4, 2)*bSO42*bSO43+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sumtermexpzso4(zso4)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44+DSO42*exp(bSO42*zox)*FH2S(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44-DSO41*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43-DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44+DSO41^2*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*SO40*bSO41*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO44-DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO41*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO42*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO41*bSO43*bSO44)/(DSO41*(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43));
ASO42 = (-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sum_termexp(4, 2)*bSO42*bSO43+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sumtermexpzso4(zso4)*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*SO40*bSO41*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO44-DSO41^2*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termexp(4, 2)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termexp(4, 2)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*SO40*bSO41*bSO43*bSO44+DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44-DSO41*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43-DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44+DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44+DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43-DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43+DSO42*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44-DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO44-DSO41*DSO42*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43)/(DSO41*(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43));
ASO43 = -(-exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44+DSO42*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*SO40*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*sum_termexp(4, 2)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*SO40*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termexp(4, 2)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termexp(4, 2)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*sum_termexp(4, 2)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43-FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43+FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44+DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41*bSO42-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41*bSO43+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*sum_termexp(4, 2)*bSO42*bSO43-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*sumtermexpzso4(zso4)*bSO42*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43)/(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43);
ASO44 = -(exp(bSO44*zso4)*DSO41*sum_termexp(4, 2)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43*exp(bSO41*zox)*bSO41-DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*SO40*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO42-exp(bSO44*zso4)*DSO41*exp(bSO42*zbio)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*exp(bSO41*zox)*bSO41+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO42*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43-DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sumtermexpzso4(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44+DSO42*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*sumtermexpzso4(zso4)*bSO42*bSO43)/(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43);
BSO41 = (DSO41*DSO42*exp(bSO42*zox)*exp(bSO44*zso4)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*SO40*DSO41*bSO42*bSO43+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sum_termexp(4, 2)*bSO42*bSO43-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*DSO41*sumtermexpzso4(zso4)*bSO42*bSO43-DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO42*bSO44+DSO42*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44-DSO42*exp(bSO42*zox)*FH2S(zso4)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO43*bSO44+DSO41*FH2S(zso4)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43-DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO42*bSO44)/(DSO41*(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43));
BSO42 = DSO42*(DSO41*exp(bSO41*zox)*sum_termexp(4, 2)*exp(bSO44*zno3)*bSO41*bSO44-DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO44*zno3)*bSO41*bSO44-DSO41*exp(bSO41*zox)*exp(bSO44*zno3)*SO40*bSO41*bSO44+DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*sum_termdev(4, 2)*bSO41-DSO41*exp(bSO41*zox)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41-exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zno3)*bSO44+FH2S(zso4)*exp(bSO44*zno3)*bSO44)*bSO43*exp(bSO43*zbio)/(DSO41*(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43));
BSO43 = exp(bSO42*zbio)*bSO42*(DSO41*exp(bSO41*zox)*sum_termexp(4, 2)*exp(bSO44*zno3)*bSO41*bSO44-DSO41*exp(bSO41*zox)*sumtermexpzso4(zso4)*exp(bSO44*zno3)*bSO41*bSO44-DSO41*exp(bSO41*zox)*exp(bSO44*zno3)*SO40*bSO41*bSO44+DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*sum_termdev(4, 2)*bSO41-DSO41*exp(bSO41*zox)*exp(bSO44*zno3)*sum_termdev(4, 2)*bSO41-exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zno3)*bSO44+FH2S(zso4)*exp(bSO44*zno3)*bSO44)/(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43);
BSO44 = (DSO41*sum_termexp(4, 2)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43*exp(bSO41*zox)*bSO41-DSO41*sumtermexpzso4(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43*exp(bSO41*zox)*bSO41-SO40*DSO41*exp(bSO42*zbio)*bSO42*exp(bSO43*zno3)*bSO43*exp(bSO41*zox)*bSO41+DSO41*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*exp(bSO41*zox)*bSO41-DSO41*exp(bSO42*zbio)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*exp(bSO41*zox)*bSO41+DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO43*exp(bSO41*zox)*bSO41-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO42*zbio)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO43*exp(bSO41*zox)*bSO41+DSO42*exp(bSO42*zox)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43+FH2S(zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43)/(DSO41*exp(bSO41*zox)*exp(bSO44*zso4)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43*exp(bSO41*zox)+DSO42*exp(bSO41*zox)*exp(bSO42*zbio)*exp(bSO43*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO42*exp(bSO44*zno3)*bSO44*exp(bSO43*zbio)*exp(bSO42*zox)*bSO42*bSO43);
           
if calcconc==1
    ztemp(1)=zox; ztemp(2)=zbio; ztemp(3)=zno3; ztemp(4)=zso4;
    Atemp(1)=ASO41; Atemp(2)=ASO42; Atemp(3)=ASO43; Atemp(4)=ASO44;
    Btemp(1)=BSO41; Btemp(2)=BSO42; Btemp(3)=BSO43; Btemp(4)=BSO44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bSO41; btemp(2)=bSO42; btemp(3)=bSO43; btemp(4)=bSO44;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DSO41;
    conc0temp=SO40;
    calconc;
    F_SO4=F_temp;
    SO4=conc;
end
    
else
%__________________________________________________________________________       
%Case 1, subcase 2: zox<zno3 <zbio< zso4
%__________________________________________________________________________
  
    
%define exponents
bSO41=w/DSO41;
bSO42=w/DSO41;
bSO43=w/DSO41;
bSO44=w/DSO42;

%LAYER 1 reactive terms: /

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: Sulfato reduction (-)
j=3; ztemp=zbio; ztemp1=zno3;
reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DSO41;
calcterm;

%LAYER 4 reactive terms: Sulfato reduction (-)
j=4; ztemp=zbio+1; ztemp1=zbio;
reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DSO42;
calcterm;

sumtermexpzso4=@(zso4) sum(term(:,4).*exp(-beta(:,4).*zso4));
sumtermdevzso4=@(zso4) sum(-term(:,4).*beta(:,4).*exp(-beta(:,4).*zso4));

%Flux of H2S through oxic interface
reacf1=k1*SO4C;
reacf2=k2*SO4C;

flux1=-(A11*exp(a11*zno3)*a12*b11*b12*reacf1-A11*exp(b11*zno3)*a11*a12*b12*reacf1-A11*exp(a11*zbio)*a12*b11*b12*reacf1...
    +A11*exp(b11*zbio)*a11*a12*b12*reacf1+A12*exp(a12*zno3)*a11*b11*b12*reacf2-A12*exp(b12*zno3)*a11*a12*b11*reacf2...
    -A12*exp(a12*zbio)*a11*b11*b12*reacf2+A12*exp(b12*zbio)*a11*a12*b11*reacf2+C01*exp(b11*zno3)*a11*a12*b12*reacf1...
    -C01*exp(b11*zbio)*a11*a12*b12*reacf1+C02*exp(b12*zno3)*a11*a12*b11*reacf2-C02*exp(b12*zbio)*a11*a12*b11*reacf2)...
    /(a11*b11*a12*b12);

flux2=@(zso4)-(reacf1*A21*exp(a21*zbio)*a22-reacf1*A21*exp(a21*zso4)*a22+reacf2*A22*exp(a22*zbio)...
    *a21-reacf2*A22*exp(a22*zso4)*a21)/(a21*a22);

FH2S=@(zso4)1/por*(flux1+flux2(zso4)); %MULTIPLY by 1/POR ????

reacf1=k1*MC*gammaCH4;
reacf2=k2*MC*gammaCH4;

FSO4=@(zso4)-1/por*(reacf1*A21*exp(a21*zso4)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zso4)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

BSO44 = @(zso4) (-DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO42+DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO42-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO41*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43+DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43+DSO41*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(3, 1)*bSO41*bSO42-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+DSO41*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43)/(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44);

fun=@(zso4)-por*DSO42*(BSO44(zso4)*bSO44*exp(bSO44*zso4)+sumtermdevzso4(zso4))-FSO4(zso4); 

zso4=fzero(fun,[zbio 1000]);

zso4(zso4<0)=0;

ASO41 = (DSO42*exp(bSO42*zox)*FH2S(zso4)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44+DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO43+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*SO40*bSO41*bSO43*bSO44-exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO44*zbio)*bSO44+exp(bSO42*zox)*bSO42*DSO41*DSO42*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44+DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41^2*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43-DSO41*exp(bSO44*zso4)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41^2*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43+exp(bSO41*zox)*exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*exp(bSO44*zbio)*SO40*bSO44-exp(bSO42*zox)*exp(bSO43*zno3)*bSO43*DSO41*DSO42*exp(bSO41*zox)*exp(bSO44*zbio)*SO40*bSO41*bSO44-DSO41*DSO42*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));
ASO42 = (DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44-exp(bSO41*zox)*DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO44+exp(bSO41*zox)*DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44+DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO43+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+exp(bSO41*zox)*exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO44*zbio)*bSO44-exp(bSO42*zox)*exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO44*zbio)*bSO41*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*SO40*bSO41*bSO43*bSO44-exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO44*zbio)*bSO44-exp(bSO41*zox)*exp(bSO42*zox)*bSO42*DSO41*DSO42*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO44+exp(bSO42*zox)*DSO41*DSO42*exp(bSO41*zox)*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO41*bSO44+exp(bSO42*zox)*bSO42*DSO41*DSO42*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO44-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44+DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41^2*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43-DSO41*exp(bSO44*zso4)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41^2*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43-DSO41*DSO42*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44+DSO42*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO43+DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43-DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));
ASO43 = -(-DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44-DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO41^2*sum_termexp(3, 2)*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41^2*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO43-DSO41*DSO42*sum_termexp(3, 1)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sum_termexp(4, 2)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO44+DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO44+DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43+DSO41^2*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43+DSO41*exp(bSO44*zso4)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43-DSO41*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43-DSO41^2*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO42+DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO42+DSO41*DSO42*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO42*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO43+DSO41*DSO42*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43+DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO43-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO43-DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));
ASO44 = -(exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(3, 1)*bSO41*bSO42-exp(bSO44*zso4)*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO42-exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43-exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43-exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO42+exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO42+DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+exp(bSO44*zso4)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+DSO42*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-exp(bSO44*zso4)*DSO41*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43+exp(bSO44*zso4)*DSO41*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43-exp(bSO44*zso4)*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+exp(bSO44*zso4)*DSO41*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43+exp(bSO44*zso4)*DSO41*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-exp(bSO44*zso4)*DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43-DSO41*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43+DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-exp(bSO44*zso4)*DSO41*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44)/(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44);
BSO41 = -(DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO42*bSO43-DSO41^2*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO42*bSO43+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO44*zbio)*bSO44+exp(bSO42*zox)*bSO42*exp(bSO43*zno3)*bSO43*DSO41*DSO42*exp(bSO44*zbio)*SO40*bSO44-DSO41^2*exp(bSO44*zso4)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41^2*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43+exp(bSO42*zox)*bSO42*DSO41*DSO42*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO44-DSO41*DSO42*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44-DSO41*exp(bSO44*zso4)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO43+DSO42*exp(bSO42*zox)*FH2S(zso4)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44+DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO43*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO42*bSO44)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));  
BSO42 = -(DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO43-DSO41^2*exp(bSO41*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO43+exp(bSO43*zno3)*bSO43*DSO42*exp(bSO41*zox)*FH2S(zso4)*exp(bSO44*zbio)*bSO44+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44-exp(bSO43*zno3)*bSO43*DSO41*DSO42*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO44*zbio)*bSO41*bSO44+exp(bSO43*zno3)*bSO43*DSO41*DSO42*exp(bSO41*zox)*exp(bSO44*zbio)*SO40*bSO41*bSO44-exp(bSO43*zno3)*bSO43*DSO42*FH2S(zso4)*exp(bSO44*zbio)*bSO44-DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+DSO41^2*exp(bSO41*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO43+DSO41*DSO42*exp(bSO41*zox)*exp(bSO43*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO41*bSO44-DSO41*DSO42*exp(bSO41*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO44)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));
BSO43 = -(DSO41^2*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 1)*bSO41*bSO42-DSO41*DSO42*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(4, 2)*bSO41*bSO42+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*sum_termdev(4, 2)*bSO41*bSO42+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO42*bSO44-DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO41*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO41*bSO44-DSO41^2*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 1)*exp(bSO44*zbio)*bSO41*bSO42-DSO41*DSO42*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO44*zbio)*bSO42*bSO44+DSO42*exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO42*bSO44+DSO41*DSO42*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO41*DSO42*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO41*DSO42*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO41*DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO44*zbio)*SO40*bSO41*bSO42*bSO44-DSO42*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO44*zbio)*bSO42*bSO44)/(DSO41*(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44));
BSO44 = (-DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO42+DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO41*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO42-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO43-DSO41*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(3, 1)*bSO42*bSO43+DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO42*bSO43-DSO41*sum_termexp(3, 1)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43+DSO41*sum_termexp(4, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*sumtermexpzso4(zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(3, 1)*bSO41*bSO42-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43+DSO41*sum_termexp(3, 2)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*SO40*bSO41*bSO42*bSO43+DSO41*exp(bSO41*zox)*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO41*bSO43+DSO41*exp(bSO42*zox)*sum_termdev(3, 2)*exp(bSO43*zbio)*bSO42*bSO43-exp(bSO41*zox)*FH2S(zso4)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO42*bSO43)/(DSO41*exp(bSO44*zso4)*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*bSO41*bSO42*bSO43-DSO41*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO43-DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44-DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO42*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO41*bSO43*bSO44+DSO42*exp(bSO41*zox)*exp(bSO42*zno3)*exp(bSO43*zbio)*exp(bSO44*zbio)*bSO41*bSO42*bSO44-DSO42*exp(bSO42*zox)*exp(bSO43*zno3)*exp(bSO44*zbio)*bSO42*bSO43*bSO44);

if calcconc==1
    ztemp(1)=zox; ztemp(2)=zno3; ztemp(3)=zbio; ztemp(4)=zso4;
    Atemp(1)=ASO41; Atemp(2)=ASO42; Atemp(3)=ASO43; Atemp(4)=ASO44;
    Btemp(1)=BSO41; Btemp(2)=BSO42; Btemp(3)=BSO43; Btemp(4)=BSO44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bSO41; btemp(2)=bSO42; btemp(3)=bSO43; btemp(4)=bSO44;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DSO41;
    conc0temp=SO40;
    calconc;
    F_SO4=F_temp;
    SO4=conc;
end

    
end

else
    
%__________________________________________________________________________           
%Case 2, subcase 1: zbio<zox<zno3<zso4
%__________________________________________________________________________

%define exponents
bSO41=w/DSO41;
bSO42=w/DSO42;
bSO43=w/DSO42;
bSO44=w/DSO42;

%LAYER 1 reactive terms: /

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: /

%LAYER 4 reactive terms: Sulfato reduction (-)
j=4; ztemp=zno3+1; ztemp1=zno3;
reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DSO42;
calcterm;

sumtermexpzso4=@(zso4) sum(term(:,4).*exp(-beta(:,4).*zso4));
sumtermdevzso4=@(zso4) sum(-term(:,4).*beta(:,4).*exp(-beta(:,4).*zso4));

%flux of H2S to oxic interface (Source of SO4)

reacf1=k1*SO4C;
reacf2=k2*SO4C;

FH2S=@(zso4)-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zso4)*a22...
    +reacf2*A22*exp(a22*zno3)*a21-reacf2*A22*exp(a22*zso4)*a21)/(a21*a22); % MULTIPLY BY 1/POR ????

% Flux of CH4 produced under zso4 that is oxidized at zso4; consumming SO4

reacf1=k1*MC*gammaCH4;
reacf2=k2*MC*gammaCH4;

FSO4=@(zso4)-1/por*(reacf1*A21*exp(a21*zso4)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zso4)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

BSO44 =@(zso4) -(DSO41*DSO42*sumtermexpzso4(zso4)*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*DSO42*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*sum_termexp(4, 2)*bSO41*bSO42*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*SO40*bSO41*bSO42*bSO43-DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zox)*exp(bSO41*zbio)*sum_termdev(4, 2)*bSO41*bSO42+DSO41*DSO42*exp(bSO42*zox)*exp(bSO43*zox)*exp(bSO41*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO41*DSO42*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*sum_termdev(4, 2)*bSO41*bSO42-DSO41*DSO42*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO42*zbio)*sum_termdev(4, 2)*bSO41*bSO43+DSO42^2*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO42*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO41*exp(bSO42*zox)*FH2S(zno3)*exp(bSO41*zbio)*exp(bSO43*zno3)*bSO41*bSO43-DSO41*FH2S(zno3)*exp(bSO41*zbio)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO41*bSO43-DSO42^2*exp(bSO43*zox)*exp(bSO42*zbio)*sum_termdev(4, 2)*bSO42*bSO43+DSO42*FH2S(zno3)*exp(bSO41*zbio)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43-DSO42*FH2S(zno3)*exp(bSO42*zbio)*exp(bSO43*zno3)*bSO42*bSO43)/((DSO41*exp(bSO44*zso4)*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*bSO41*bSO42*bSO43-DSO41*exp(bSO42*zox)*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO44*zno3)*bSO41*bSO42*bSO44+DSO41*exp(bSO42*zox)*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44-DSO41*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO43+DSO41*exp(bSO42*zox)*exp(bSO41*zbio)*exp(bSO43*zno3)*exp(bSO44*zno3)*bSO41*bSO42*bSO44-DSO41*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO42*zbio)*exp(bSO44*zno3)*bSO41*bSO43*bSO44+DSO42*exp(bSO43*zox)*exp(bSO41*zbio)*exp(bSO42*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44-DSO42*exp(bSO43*zox)*exp(bSO42*zbio)*exp(bSO44*zno3)*bSO42*bSO43*bSO44)*DSO42);
fun=@(zso4)-por*DSO42*(BSO44(zso4)*bSO44*exp(bSO44*zso4)+sumtermdevzso4(zso4))-FSO4(zso4);  

zso4=fzero(fun,[0 1000]);
zso4(zso4<0)=0;

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zox; ztemp(3)=zno3; ztemp(4)=zso4;
    Atemp(1)=ASO41; Atemp(2)=ASO42; Atemp(3)=ASO43; Atemp(4)=ASO44;
    Btemp(1)=BSO41; Btemp(2)=BSO42; Btemp(3)=BSO43; Btemp(4)=BSO44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bSO41; btemp(2)=bSO42; btemp(3)=bSO43; btemp(4)=bSO44;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DSO41;
    conc0temp=SO40;
    calconc;
    F_SO4=F_temp;
    SO4=conc;
end

end
end


