% SOLVE DIC

%zbio<zso4

%LAYER 1 OM DEGRADATION (+)
j=1; ztemp=zbio; ztemp1=0;
reac1=DICC1;
reac2=DICC1;
ktemp=0;
Dtemp=DDIC1;
calcterm;

%LAYER 2 OM DEGRADATION (+)
j=2; ztemp=zso4; ztemp1=zbio;
reac1=DICC1;
reac2=DICC1;
ktemp=0;
Dtemp=DDIC2;
calcterm;

%LAYER 3 OM DEGRADATION (Methanogenesis) (+)
j=3; ztemp=zinf; ztemp1=zso4;
reac1=DICC2;
reac2=DICC2;
ktemp=0;
Dtemp=DDIC2;
calcterm;

%define exponents
bDIC1=w/DDIC1;
bDIC2=w/DDIC2;
bDIC3=w/DDIC2;

%Flux of CH4 at zso4
reacf1=k1*MC;
reacf2=k2*MC;

limsup=zso4; liminf=zinf;
reacf1=MC; reacf2=MC;
calcflux2;
FCH4=fluxtemp; % *1/POR ???? %comment: - flux, so we get + gamma/phi*flux

ADIC1 = (DDIC1*DIC0*bDIC1*exp(bDIC1*zbio) + DDIC1*bDIC1*-sum_term(1)*exp(bDIC1*zbio) - DDIC1*-sum_termdev(1,1) + DDIC2*-sum_termdev(2,2))*exp(-bDIC1*zbio)/(DDIC1*bDIC1);
BDIC1 = (DDIC1*-sum_termdev(1,1) - DDIC2*-sum_termdev(2,2))*exp(-bDIC1*zbio)/(DDIC1*bDIC1);
ADIC2 = (DDIC1*DDIC2*DIC0*bDIC1*bDIC2*exp(bDIC1*zbio + bDIC2*zso4) + DDIC1*DDIC2*bDIC1*bDIC2*-sum_term(1)*exp(bDIC1*zbio + bDIC2*zso4) - DDIC1*DDIC2*bDIC2*-sum_termdev(1,1)*exp(bDIC2*zso4) + DDIC2^2*bDIC2*-sum_termdev(2,2)*exp(bDIC2*zso4) - (((a22*-term(2,2) - a22*-term(2,3))*exp(a22*zso4) + (a21*-term(1,2) - a21*-term(1,3))*exp(a21*zso4))*DDIC1*DDIC2*bDIC1 - DDIC1*(gammaCH4)*FCH4*bDIC1)*exp(bDIC1*zbio + bDIC2*zbio) - (DDIC1*DDIC2*bDIC1*bDIC2*-sum_termexp(1,1)*exp(bDIC2*zso4) - DDIC1*DDIC2*bDIC1*bDIC2*-sum_termexp(2,2)*exp(bDIC2*zso4) - DDIC1*DDIC2*bDIC2*-sum_termdev(1,1)*exp(bDIC2*zso4) + DDIC2^2*bDIC2*-sum_termdev(2,2)*exp(bDIC2*zso4))*exp(bDIC1*zbio))*exp(-bDIC1*zbio - bDIC2*zso4)/(DDIC1*DDIC2*bDIC1*bDIC2);
BDIC2 = (((a22*-term(2,2) - a22*-term(2,3))*exp(a22*zso4) + (a21*-term(1,2) - a21*-term(1,3))*exp(a21*zso4))*DDIC2 - (gammaCH4)*FCH4)*exp(-bDIC2*zso4)/(DDIC2*bDIC2);
ADIC3 = (DDIC1*DDIC2*DIC0*bDIC1*bDIC2*exp(bDIC1*zbio + bDIC2*zso4) + DDIC1*DDIC2*bDIC1*bDIC2*-sum_term(1)*exp(bDIC1*zbio + bDIC2*zso4) - DDIC1*DDIC2*bDIC2*-sum_termdev(1,1)*exp(bDIC2*zso4) + DDIC2^2*bDIC2*-sum_termdev(2,2)*exp(bDIC2*zso4) - (((a22*-term(2,2) - a22*-term(2,3))*exp(a22*zso4) + (a21*-term(1,2) - a21*-term(1,3))*exp(a21*zso4))*DDIC1*DDIC2*bDIC1 - DDIC1*(gammaCH4)*FCH4*bDIC1)*exp(bDIC1*zbio + bDIC2*zbio) - (DDIC1*DDIC2*bDIC1*bDIC2*-sum_termexp(1,1)*exp(bDIC2*zso4) - DDIC1*DDIC2*bDIC1*bDIC2*-sum_termexp(2,2)*exp(bDIC2*zso4) + DDIC2^2*bDIC2*-sum_termdev(2,2)*exp(bDIC2*zso4) + DDIC1*(gammaCH4)*FCH4*bDIC1*exp(bDIC2*zso4) - ((((a21 - bDIC2)*-term(1,2) - (a21 - bDIC2)*-term(1,3))*exp(a21*zso4) + ((a22 - bDIC2)*-term(2,2) - (a22 - bDIC2)*-term(2,3))*exp(a22*zso4))*bDIC1*exp(bDIC2*zso4) + bDIC2*-sum_termdev(1,1)*exp(bDIC2*zso4))*DDIC1*DDIC2)*exp(bDIC1*zbio))*exp(-bDIC1*zbio - bDIC2*zso4)/(DDIC1*DDIC2*bDIC1*bDIC2);
BDIC3 = 0;

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zso4; ztemp(3)=zinf;
    Atemp(1)=ADIC1; Atemp(2)=ADIC2; Atemp(3)=ADIC3;
    Btemp(1)=BDIC1; Btemp(2)=BDIC2; Btemp(3)=BDIC3;
    atemp(1)=0; atemp(2)=0; atemp(3)=0;
    btemp(1)=bDIC1; btemp(2)=bDIC2; btemp(3)=bDIC3;
    Qtemp(1)=0; Qtemp(2)=0; Qtemp(3)=0;
    Dtemp=DDIC1;
    conc0temp=DIC0;
    calconc;
    F_DIC=F_temp;
    DIC=conc;
end
