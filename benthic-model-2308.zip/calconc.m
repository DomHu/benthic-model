j=1;
for i=1:1001
    z=(i-1)/10;
    if (z<=ztemp(j))
        conc(i)=Atemp(j)*exp(atemp(j)*z)+Btemp(j)*exp(btemp(j)*z)...
                +sum(term(:,j).*exp(-beta(:,j).*z))...
                +Qtemp(j);
    elseif (j<length(ztemp))
        j=j+1;
        conc(i)=Atemp(j)*exp(atemp(j)*z)+Btemp(j)*exp(btemp(j)*z)...
                +sum(term(:,j).*exp(-beta(:,j).*z))...
                +Qtemp(j);
    else
        conc(i)=conclim;
    end
end

% Flux at SWI: -D*(dS/dz)+w*S0

F_temp=-por*Dtemp*(Atemp(1).*atemp(1)+Btemp(1).*btemp(1)...
        +sum(-beta(:,1).*term(:,1)))...
        +w*conc0temp;

term=zeros(6,6); beta= zeros(6,6);
clear Atemp; clear Btemp; clear atemp; clear btemp; clear Qtemp; clear conclim; clear ztemp;

      