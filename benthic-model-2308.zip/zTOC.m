%__________________________________________________________________________________________________________________________
%Organic matter- 2 Fractions
%__________________________________________________________________________________________________________________________
a11=(w-sqrt(w^2+4*DC1*k1))/(2*DC1);
b11=(w+sqrt(w^2+4*DC1*k1))/(2*DC1);
a21=(-k1/w);
A11=-(C01*b11*exp(b11*zbio))/(a11*exp(a11*zbio)-b11*exp(b11*zbio));
A21=(A11*(exp(a11*zbio)-exp(b11*zbio))+C01*exp(b11*zbio))/exp(a21*zbio);

a12=(w-sqrt(w^2+4*DC1*k2))/(2*DC1);
b12=(w+sqrt(w^2+4*DC1*k2))/(2*DC1);
a22=(-k2/w);
A12=-(C02*b12*exp(b12*zbio))/(a12*exp(a12*zbio)-b12*exp(b12*zbio));
A22=(A12*(exp(a12*zbio)-exp(b12*zbio))+C02*exp(b12*zbio))/exp(a22*zbio);

for i=1:101
    z=i-1;
    if(z<zbio)
        C11(i)=A11*(exp(a11*z)-exp(b11*z))+C01*exp(b11*z);
        C21(i)=0;
        C12(i)=A12*(exp(a12*z)-exp(b12*z))+C02*exp(b12*z);
        C22(i)=0;
        
        C1(i)=C11(i);
        C2(i)=C12(i);
        C(i)=C1(i)+C2(i);
    else
        C11(i)=0;
        C21(i)=A21*exp(a21*z);
        C12(i)=0;
        C22(i)=A22*exp(a22*z);
        
        C1(i)=C21(i);
        C2(i)=C22(i);
        C(i)=C1(i)+C2(i);
    end

end


%Flux through lower boundary zlow
zlow=100; %cm
F_TOC1=w*A21*exp(a21*zlow);                                                      
F_TOC2=w*A22*exp(a22*zlow);
F_TOC=F_TOC1+F_TOC2;