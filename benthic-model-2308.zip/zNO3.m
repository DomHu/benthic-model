% Solve N03

if (zox<=zbio)
%_________________________________________________________________________
% CASE 1 ZOX<ZBIO, ASSUME ZNO3>ZBIO
%_________________________________________________________________________

%LAYER 1 reactive terms: Nitrification (+) 
j=1; ztemp=zox; ztemp1=0;
reac1=gamma*NC1;
reac2=gamma*NC2;
ktemp=0;
Dtemp=DN1;
calcterm;

%LAYER 2 reactive terms: Denitrification (-) 
j=2; ztemp=zbio; ztemp1=zox;
reac1=-NO3CR;
reac2=-NO3CR;
ktemp=0;
Dtemp=DN1;
calcterm;

%LAYER 3 reactive terms: Denitrification (-)
j=3; ztemp=zbio+1; ztemp1=zbio;
reac1=-NO3CR;
reac2=-NO3CR;
ktemp=0;
Dtemp=DN2;
calcterm;

%define exponents
bn1=w/DN1;
bn2=w/DN1;
bn3=w/DN2;

sumtermexpzno3=@(zno3) sum(term(:,3).*exp(-beta(:,3).*zno3));
sumtermdevzno3=@(zno3) sum(-term(:,3).*beta(:,3).*exp(-beta(:,3).*zno3));

%_________________________________________________________________________
% FIND ZNO3
% DN2*(dNO33/dz)(zno3)=0
%  => DN2*(BN3*bN3*exp(bN3*zno3)+sumtermdevzno3=0
%____________________________________________________________________

%Flux of NH4 through ZOX --> NO3 prod. OM degrad from ZNO3 -> ZINF

reacf1=k1*gamma*NC1; % Nitrification
reacf2=k2*gamma*NC2; % Nitrification

FNO3=@(zno3)-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zno3)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

BN3=@(zno3)(((-DN1*bn1*sum_termdev(2, 1)+DN2*bn1*sum_termdev(3, 2)-bn2*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)-DN1*bn1*sum_termexp(2, 1)+DN1*bn1*sum_termexp(2, 2)-DN1*bn1*sumtermexpzno3(zno3)+DN1*bn1*sum_termexp(3, 2)-DN1*bn1*NO30+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3(zno3)))*exp(bn2*zbio)+exp(bn2*zox)*(bn1-bn2)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*exp(bn1*zox)+((DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3(zno3))*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*bn2)/((bn1*((DN1*bn2-DN2*bn3)*exp(bn3*zbio)-bn2*DN1*exp(bn3*zno3))*exp(bn2*zbio)+DN2*exp(bn2*zox)*exp(bn3*zbio)*bn3*(bn1-bn2))*exp(bn1*zox)+DN2*exp(bn3*zbio)*bn3*exp(bn2*zox)*bn2);

fun=@(zno3)-por*DN2*(BN3(zno3)*bn3*exp(bn3*zno3)+sumtermdevzno3(zno3));

zno3=fzero(fun,[zbio]);

if (zno3>=zbio)
    
FNO3=-FNO3(zno3);

sumtermexpzno3=sum(term(:,3).*exp(-beta(:,3).*zno3));
sumtermdevzno3=sum(-term(:,3).*beta(:,3).*exp(-beta(:,3).*zno3));

AN1 = (((-DN1*DN2*bn3*(bn1-bn2)*(sum_term(1)-NO30)*exp(bn1*zox)+DN1*DN2*bn3*sum_termdev(1, 1)-DN1*DN2*bn3*sum_termdev(2, 2)+DN1^2*sum_termdev(2, 1)*bn2-DN2*(DN1*sum_termdev(3, 2)*bn2+bn3*(DN1*sum_termexp(1, 1)*bn2+DN1*sum_termexp(2, 1)*bn2-DN1*sum_termexp(2, 2)*bn2+DN1*sumtermexpzno3*bn2-DN1*sum_termexp(3, 2)*bn2+FNO3)))*exp(bn2*zox)-(DN1*bn2-DN2*bn3)*(DN1*bn1*(sum_term(1)-NO30)*exp(bn1*zox)-DN1*sum_termdev(1, 1)+DN1*sum_termdev(2, 2)+FNO3)*exp(bn2*zbio))*exp(bn3*zbio)+((-DN1*sum_termdev(2, 1)+DN2*sum_termdev(3, 2))*exp(bn2*zox)+(DN1*bn1*(sum_term(1)-NO30)*exp(bn1*zox)-DN1*sum_termdev(1, 1)+DN1*sum_termdev(2, 2)+FNO3)*exp(bn2*zbio))*bn2*DN1*exp(bn3*zno3))/(((DN2*bn3*((bn1-bn2)*exp(bn1*zox)+bn2)*exp(bn2*zox)+exp(bn1*zox)*exp(bn2*zbio)*bn1*(DN1*bn2-DN2*bn3))*exp(bn3*zbio)-DN1*exp(bn1*zox)*exp(bn2*zbio)*exp(bn3*zno3)*bn1*bn2)*DN1);
AN2 = (((-(DN1*bn2-DN2*bn3)*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)+DN1*bn1*sum_termexp(2, 2)-DN1*bn1*NO30+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(bn1-bn2)*DN1*(DN1*sum_termdev(2, 1)-DN2*(sum_termdev(3, 2)+bn3*(sum_termexp(2, 1)+sumtermexpzno3-sum_termexp(3, 2)))))*exp(bn1*zox)+(DN1*bn2-DN2*bn3)*(DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*bn2*DN1*(DN1*sum_termdev(2, 1)-DN2*(sum_termdev(3, 2)+bn3*(sum_termexp(2, 1)+sumtermexpzno3-sum_termexp(3, 2)))))*exp(bn3*zbio)+DN1*((bn2*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)+DN1*bn1*sum_termexp(2, 2)-DN1*bn1*NO30+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)-exp(bn2*zox)*(bn1-bn2)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*exp(bn1*zox)-((DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*bn2)*exp(bn3*zno3))/((((bn1*(DN1*bn2-DN2*bn3)*exp(bn2*zbio)+DN2*exp(bn2*zox)*bn3*(bn1-bn2))*exp(bn1*zox)+DN2*exp(bn2*zox)*bn2*bn3)*exp(bn3*zbio)-DN1*exp(bn1*zox)*exp(bn2*zbio)*exp(bn3*zno3)*bn1*bn2)*DN1);
AN3 = ((((DN1*bn1*sum_termdev(2, 1)-DN2*bn1*sum_termdev(3, 2)+bn2*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)-DN1*bn1*sum_termexp(2, 1)+DN1*bn1*sum_termexp(2, 2)+DN1*bn1*sum_termexp(3, 2)-DN1*bn1*NO30+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3))*exp(bn2*zbio)-exp(bn2*zox)*(bn1-bn2)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*exp(bn3*zno3)-sumtermexpzno3*(bn1*(DN1*bn2-DN2*bn3)*exp(bn2*zbio)+DN2*exp(bn2*zox)*bn3*(bn1-bn2))*exp(bn3*zbio))*exp(bn1*zox)-bn2*(((DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*exp(bn3*zno3)+sumtermexpzno3*DN2*exp(bn2*zox)*exp(bn3*zbio)*bn3))/((-DN1*exp(bn2*zbio)*bn1*bn2*exp(bn3*zno3)+exp(bn3*zbio)*(bn1*(DN1*bn2-DN2*bn3)*exp(bn2*zbio)+DN2*exp(bn2*zox)*bn3*(bn1-bn2)))*exp(bn1*zox)+DN2*exp(bn3*zbio)*bn3*exp(bn2*zox)*bn2);
BN1 = (((-DN1*DN2*bn3*sum_termdev(1, 1)+DN1*DN2*bn3*sum_termdev(2, 2)-DN1^2*sum_termdev(2, 1)*bn2-DN2*(-DN1*sum_termdev(3, 2)*bn2+bn3*(DN1*sum_term(1)*bn2-DN1*sum_termexp(1, 1)*bn2-DN1*sum_termexp(2, 1)*bn2+DN1*sum_termexp(2, 2)*bn2-DN1*sumtermexpzno3*bn2+DN1*sum_termexp(3, 2)*bn2-DN1*bn2*NO30-FNO3)))*exp(bn2*zox)-(DN1*bn2-DN2*bn3)*(DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio))*exp(bn3*zbio)+((DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*bn2*DN1*exp(bn3*zno3))/(((DN2*bn3*((bn1-bn2)*exp(bn1*zox)+bn2)*exp(bn2*zox)+exp(bn1*zox)*exp(bn2*zbio)*bn1*(DN1*bn2-DN2*bn3))*exp(bn3*zbio)-DN1*exp(bn1*zox)*exp(bn2*zbio)*exp(bn3*zno3)*bn1*bn2)*DN1);
BN2 = (((-DN1*DN2*bn3*sum_termdev(1, 1)-DN1^2*sum_termdev(2, 1)*bn1-DN2*(-DN1*bn3*sum_termdev(2, 2)-DN1*bn1*sum_termdev(3, 2)+bn3*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)-DN1*bn1*sum_termexp(2, 1)+DN1*bn1*sum_termexp(2, 2)-DN1*bn1*sumtermexpzno3+DN1*bn1*sum_termexp(3, 2)-DN1*bn1*NO30-FNO3)))*exp(bn1*zox)+DN2*bn3*(DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3))*exp(bn3*zbio)+DN1*exp(bn1*zox)*exp(bn3*zno3)*bn1*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))/((((bn1*(DN1*bn2-DN2*bn3)*exp(bn2*zbio)+DN2*exp(bn2*zox)*bn3*(bn1-bn2))*exp(bn1*zox)+DN2*exp(bn2*zox)*bn2*bn3)*exp(bn3*zbio)-DN1*exp(bn1*zox)*exp(bn2*zbio)*exp(bn3*zno3)*bn1*bn2)*DN1);
BN3 = (((-DN1*bn1*sum_termdev(2, 1)+DN2*bn1*sum_termdev(3, 2)-bn2*(DN1*sum_term(1)*bn1-DN1*bn1*sum_termexp(1, 1)-DN1*bn1*sum_termexp(2, 1)+DN1*bn1*sum_termexp(2, 2)-DN1*bn1*sumtermexpzno3+DN1*bn1*sum_termexp(3, 2)-DN1*bn1*NO30+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3))*exp(bn2*zbio)+exp(bn2*zox)*(bn1-bn2)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*exp(bn1*zox)+((DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(2, 1)-DN2*sum_termdev(3, 2)))*bn2)/((bn1*((DN1*bn2-DN2*bn3)*exp(bn3*zbio)-bn2*DN1*exp(bn3*zno3))*exp(bn2*zbio)+DN2*exp(bn2*zox)*exp(bn3*zbio)*bn3*(bn1-bn2))*exp(bn1*zox)+DN2*exp(bn3*zbio)*bn3*exp(bn2*zox)*bn2);

if calcconc==1
    ztemp(1)=zox; ztemp(2)=zbio; ztemp(3)=zno3;
    Atemp(1)=AN1; Atemp(2)=AN2; Atemp(3)=AN3;
    Btemp(1)=BN1; Btemp(2)=BN2; Btemp(3)=BN3;
    atemp(1)=0; atemp(2)=0; atemp(3)=0;
    btemp(1)=bn1; btemp(2)=bn2; btemp(3)=bn3;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DN1;
    conc0temp=NO30;
    calconc;
    F_NO3=F_temp;
    NO3=conc;
end

else
    
% zox<zno3<zbio
    
%LAYER 1 reactive terms: Nitrification (+) 
j=1; ztemp=zox; ztemp1=0;
reac1=gamma*NC1;
reac2=gamma*NC2;
ktemp=0;
Dtemp=DN1;
calcterm;

%LAYER 2 reactive terms: Denitrification (-) 
j=2; ztemp=zox+1; ztemp1=zox;
reac1=-NO3CR;
reac2=-NO3CR;
ktemp=0;
Dtemp=DN1;
calcterm;

%define exponents
bn1=w/DN1;
bn2=w/DN1;

flux1=@(zno3)-(A11*exp(a11*zno3)*a12*b11*b12*reacf1-A11*exp(b11*zno3)*a11*a12*b12*reacf1-A11*exp(a11*zbio)*a12*b11*b12*reacf1...
    +A11*exp(b11*zbio)*a11*a12*b12*reacf1+A12*exp(a12*zno3)*a11*b11*b12*reacf2-A12*exp(b12*zno3)*a11*a12*b11*reacf2...
    -A12*exp(a12*zbio)*a11*b11*b12*reacf2+A12*exp(b12*zbio)*a11*a12*b11*reacf2+C01*exp(b11*zno3)*a11*a12*b12*reacf1...
    -C01*exp(b11*zbio)*a11*a12*b12*reacf1+C02*exp(b12*zno3)*a11*a12*b11*reacf2-C02*exp(b12*zbio)*a11*a12*b11*reacf2)...
    /(a11*b11*a12*b12);

flux2=-(reacf1*A21*exp(a21*zbio)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zbio)*a21-reacf2*A22*exp(a22*zinf)*a21)...
    /(a21*a22);

FNO3=@(zno3)1/por*(flux1(zno3)+flux2);

sumtermexpzno3=@(zno3) sum(term(:,2).*exp(-beta(:,2).*zno3));
sumtermdevzno3=@(zno3) sum(-term(:,2).*beta(:,2).*exp(-beta(:,2).*zno3));

BN2=@(zno3) -(NO30*DN1*exp(bn1*zox)*bn1+sumtermexpzno3(zno3)*DN1*exp(bn1*zox)*bn1-sum_term(1)*DN1*exp(bn1*zox)*bn1+sum_termexp(1, 1)*DN1*exp(bn1*zox)*bn1-sum_termexp(2, 2)*DN1*exp(bn1*zox)*bn1-DN1*exp(bn1*zox)*sum_termdev(1, 1)+DN1*exp(bn1*zox)*sum_termdev(2, 2)+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)+FNO3(zno3)*exp(bn1*zox)-FNO3(zno3))/((exp(bn2*zno3)*exp(bn1*zox)*bn1-exp(bn2*zox)*exp(bn1*zox)*bn1+exp(bn2*zox)*bn2*exp(bn1*zox)-exp(bn2*zox)*bn2)*DN1);

fun=@(zno3)-por*DN1*(BN2(zno3)*bn2*exp(bn2*zno3)+sumtermdevzno3(zno3));

zno3=fzero(fun,[zbio]);

FNO3=FNO3(zno3);
sumtermexpzno3=sum(term(:,2).*exp(-beta(:,2).*zno3));
sumtermdevzno3=sum(-term(:,2).*beta(:,2).*exp(-beta(:,2).*zno3));

BN2 = -(NO30*DN1*exp(bn1*zox)*bn1+sumtermexpzno3*DN1*exp(bn1*zox)*bn1-sum_term(1)*DN1*exp(bn1*zox)*bn1+sum_termexp(1, 1)*DN1*exp(bn1*zox)*bn1-sum_termexp(2, 2)*DN1*exp(bn1*zox)*bn1-DN1*exp(bn1*zox)*sum_termdev(1, 1)+DN1*exp(bn1*zox)*sum_termdev(2, 2)+DN1*sum_termdev(1, 1)-DN1*sum_termdev(2, 2)+FNO3*exp(bn1*zox)-FNO3)/((exp(bn2*zno3)*exp(bn1*zox)*bn1-exp(bn2*zox)*exp(bn1*zox)*bn1+exp(bn2*zox)*bn2*exp(bn1*zox)-exp(bn2*zox)*bn2)*DN1);
AN1 = (DN1*NO30*exp(bn1*zox)*exp(bn2*zno3)*bn1-DN1*NO30*exp(bn1*zox)*exp(bn2*zox)*bn1+DN1*NO30*exp(bn1*zox)*exp(bn2*zox)*bn2-DN1*exp(bn1*zox)*sum_term(1)*exp(bn2*zno3)*bn1+DN1*exp(bn1*zox)*exp(bn2*zox)*sum_term(1)*bn1-DN1*exp(bn1*zox)*exp(bn2*zox)*sum_term(1)*bn2+DN1*exp(bn2*zox)*sumtermexpzno3*bn2+DN1*sum_termexp(1, 1)*exp(bn2*zox)*bn2-DN1*sum_termexp(2, 2)*exp(bn2*zox)*bn2+DN1*sum_termdev(1, 1)*exp(bn2*zno3)-DN1*sum_termdev(2, 2)*exp(bn2*zno3)-DN1*sum_termdev(1, 1)*exp(bn2*zox)+DN1*exp(bn2*zox)*sum_termdev(2, 2)-FNO3*exp(bn2*zno3)+FNO3*exp(bn2*zox))/((exp(bn2*zno3)*exp(bn1*zox)*bn1-exp(bn2*zox)*exp(bn1*zox)*bn1+exp(bn2*zox)*bn2*exp(bn1*zox)-exp(bn2*zox)*bn2)*DN1);
AN2 = (DN1*NO30*exp(bn1*zox)*exp(bn2*zno3)*bn1-DN1*exp(bn1*zox)*sum_term(1)*exp(bn2*zno3)*bn1+DN1*sum_termexp(1, 1)*exp(bn1*zox)*exp(bn2*zno3)*bn1-DN1*sum_termexp(2, 2)*exp(bn1*zox)*exp(bn2*zno3)*bn1+DN1*exp(bn1*zox)*exp(bn2*zox)*sumtermexpzno3*bn1-DN1*exp(bn1*zox)*exp(bn2*zox)*sumtermexpzno3*bn2-DN1*exp(bn1*zox)*sum_termdev(1, 1)*exp(bn2*zno3)+DN1*exp(bn1*zox)*sum_termdev(2, 2)*exp(bn2*zno3)+DN1*exp(bn2*zox)*sumtermexpzno3*bn2+DN1*sum_termdev(1, 1)*exp(bn2*zno3)-DN1*sum_termdev(2, 2)*exp(bn2*zno3)+FNO3*exp(bn2*zno3)*exp(bn1*zox)-FNO3*exp(bn2*zno3))/((exp(bn2*zno3)*exp(bn1*zox)*bn1-exp(bn2*zox)*exp(bn1*zox)*bn1+exp(bn2*zox)*bn2*exp(bn1*zox)-exp(bn2*zox)*bn2)*DN1);
BN1 = -(DN1*NO30*exp(bn2*zox)*bn2+DN1*exp(bn2*zox)*sumtermexpzno3*bn2-DN1*exp(bn2*zox)*sum_term(1)*bn2+DN1*sum_termexp(1, 1)*exp(bn2*zox)*bn2-DN1*sum_termexp(2, 2)*exp(bn2*zox)*bn2+DN1*sum_termdev(1, 1)*exp(bn2*zno3)-DN1*sum_termdev(2, 2)*exp(bn2*zno3)-DN1*sum_termdev(1, 1)*exp(bn2*zox)+DN1*exp(bn2*zox)*sum_termdev(2, 2)-FNO3*exp(bn2*zno3)+FNO3*exp(bn2*zox))/((exp(bn2*zno3)*exp(bn1*zox)*bn1-exp(bn2*zox)*exp(bn1*zox)*bn1+exp(bn2*zox)*bn2*exp(bn1*zox)-exp(bn2*zox)*bn2)*DN1);

if calcconc==1
    ztemp(1)=zox; ztemp(2)=zno3; 
    Atemp(1)=AN1; Atemp(2)=AN2; 
    Btemp(1)=BN1; Btemp(2)=BN2; 
    atemp(1)=0; atemp(2)=0; 
    btemp(1)=bn1; btemp(2)=bn2; 
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DN1;
    conc0temp=NO30;
    calconc;
    F_NO3=F_temp;
    NO3=conc;
end

end

else
    
%_________________________________________________________________________
%CASE 2 ZBIO<ZOX<ZNO3       
%_________________________________________________________________________         
 
%LAYER 1 reactive terms: Nitrification (+) 
j=1; ztemp=zbio; ztemp1=0;
reac1=gamma*NC1;
reac2=gamma*NC2;
ktemp=0;
Dtemp=DN1;
calcterm;

%LAYER 2 reactive terms: Nitrification (+) 
j=2; ztemp=zox; ztemp1=zbio;
reac1=gamma*NC1;
reac2=gamma*NC2;
ktemp=0;
Dtemp=DN1;
calcterm;

%LAYER 3 reactive terms: Denitrification (-)
j=3; ztemp=zox+1; ztemp1=zox;
reac1=-NO3CR;
reac2=-NO3CR;
ktemp=0;
Dtemp=DN2;
calcterm;

%define exponents
bn1=w/DN1;
bn2=w/DN1;
bn3=w/DN2;

%_________________________________________________________________________
% FIND ZNO3
% DN2*(dNO33/dz)(zno3)=0
%  => DN2*(BN3*bN3*exp(bN3*zno3)+sumtermdevzno3=0
%____________________________________________________________________

reacf1=k1*gamma*NC1; % Nitrification (+) 
reacf2=k2*gamma*NC2; % Nitrification (+) 

sumtermexpzno3=@(zno3) sum(term(:,3).*exp(-beta(:,3).*zno3));
sumtermdevzno3=@(zno3) sum(-term(:,3).*beta(:,3).*exp(-beta(:,3).*zno3));

FNO3=@(zno3)-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zno3)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

BN3=@(zno3) (((-DN1*sum_termdev(2, 1)*DN2*bn1+DN1*DN2*bn1*sum_termdev(3, 2)-DN1*DN2*bn2*sum_termdev(1, 1)+DN2^2*bn2*sum_termdev(2, 2)+bn1*(DN2*bn2*sum_termexp(1, 1)+DN2*bn2*sum_termexp(2, 1)-DN2*bn2*sum_termexp(2, 2)-DN2*bn2*sum_termexp(3, 2)-sum_term(1)*DN2*bn2+bn2*(sumtermexpzno3(zno3)+NO30)*DN2+FNO3(zno3))*DN1)*exp(bn2*zox)+(sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3(zno3))*(DN1*bn1-DN2*bn2)*exp(bn2*zbio))*exp(bn1*zbio)+((sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3(zno3))*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*bn2*DN2)/(((bn1*DN1*((bn2-bn3)*exp(bn3*zox)-exp(bn3*zno3)*bn2)*exp(bn2*zox)+exp(bn3*zox)*exp(bn2*zbio)*bn3*(DN1*bn1-DN2*bn2))*exp(bn1*zbio)+DN2*exp(bn3*zox)*exp(bn2*zbio)*bn2*bn3)*DN2);

fun=@(zno3)-por*DN2*(BN3(zno3)*bn3*exp(bn3*zno3)+sumtermdevzno3(zno3));

zno3=fzero(fun,[zox 100]); 

sumtermexpzno3=sum(term(:,3).*exp(-beta(:,3).*zno3));
sumtermdevzno3=sum(-term(:,3).*beta(:,3).*exp(-beta(:,3).*zno3));

FNO3=FNO3(zno3);

AN1 = (((-bn3*(sum_term(1)-NO30)*(DN1*bn1-DN2*bn2)*exp(bn1*zbio)+DN1*sum_termdev(1, 1)*bn3-DN2*bn3*sum_termdev(2, 2)-bn2*(sumtermexpzno3*DN2*bn3+DN2*bn3*sum_termexp(1, 1)+DN2*bn3*sum_termexp(2, 1)-DN2*bn3*sum_termexp(2, 2)-DN2*bn3*sum_termexp(3, 2)-sum_termdev(2, 1)*DN2+sum_termdev(3, 2)*DN2+FNO3))*exp(bn2*zbio)-(bn2-bn3)*(DN1*bn1*(sum_term(1)-NO30)*exp(bn1*zbio)-DN1*sum_termdev(1, 1)+sum_termdev(2, 2)*DN2)*exp(bn2*zox))*exp(bn3*zox)+bn2*((-sum_termdev(2, 1)*DN2+sum_termdev(3, 2)*DN2+FNO3)*exp(bn2*zbio)+(DN1*bn1*(sum_term(1)-NO30)*exp(bn1*zbio)-DN1*sum_termdev(1, 1)+sum_termdev(2, 2)*DN2)*exp(bn2*zox))*exp(bn3*zno3))/((bn3*((DN1*bn1-DN2*bn2)*exp(bn1*zbio)+DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*exp(bn1*zbio)*bn1*(bn2-bn3))*exp(bn3*zox)-DN1*exp(bn1*zbio)*bn1*exp(bn2*zox)*bn2*exp(bn3*zno3));
AN2 = (((-(sumtermexpzno3*DN2*bn3+DN2*bn3*sum_termexp(2, 1)-DN2*bn3*sum_termexp(3, 2)-sum_termdev(2, 1)*DN2+sum_termdev(3, 2)*DN2+FNO3)*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)-(bn2-bn3)*DN2*exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2+DN1*bn1*(sum_term(1)-sum_termexp(1, 1)+sum_termexp(2, 2)-NO30)))*exp(bn3*zox)+(-(sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)+bn2*DN2*exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2+DN1*bn1*(sum_term(1)-sum_termexp(1, 1)+sum_termexp(2, 2)-NO30)))*exp(bn3*zno3))*exp(bn1*zbio)+DN2*((-bn2*(sumtermexpzno3*DN2*bn3+DN2*bn3*sum_termexp(2, 1)-DN2*bn3*sum_termexp(3, 2)-sum_termdev(2, 1)*DN2+sum_termdev(3, 2)*DN2+FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(bn2-bn3)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*exp(bn3*zox)-((sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*bn2*exp(bn3*zno3)))/((((bn3*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*bn1*(bn2-bn3))*exp(bn3*zox)-DN1*exp(bn2*zox)*exp(bn3*zno3)*bn1*bn2)*exp(bn1*zbio)+DN2*exp(bn3*zox)*exp(bn2*zbio)*bn2*bn3)*DN2);
AN3 = ((((DN1*sum_termdev(2, 1)*DN2*bn1-DN1*DN2*bn1*sum_termdev(3, 2)+DN1*DN2*bn2*sum_termdev(1, 1)-DN2^2*bn2*sum_termdev(2, 2)+DN1*bn1*(sum_term(1)*DN2*bn2-DN2*bn2*sum_termexp(1, 1)-DN2*bn2*sum_termexp(2, 1)+DN2*bn2*sum_termexp(2, 2)+DN2*bn2*sum_termexp(3, 2)-DN2*bn2*NO30-FNO3))*exp(bn2*zox)-(sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*(DN1*bn1-DN2*bn2)*exp(bn2*zbio))*exp(bn3*zno3)-sumtermexpzno3*(bn3*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*bn1*(bn2-bn3))*DN2*exp(bn3*zox))*exp(bn1*zbio)-bn2*DN2*(((sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*exp(bn3*zno3)+sumtermexpzno3*DN2*exp(bn3*zox)*exp(bn2*zbio)*bn3))/((((bn3*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*bn1*(bn2-bn3))*exp(bn3*zox)-DN1*exp(bn2*zox)*exp(bn3*zno3)*bn1*bn2)*exp(bn1*zbio)+DN2*exp(bn3*zox)*exp(bn2*zbio)*bn2*bn3)*DN2);
BN1 = (((-DN1*sum_termdev(1, 1)*bn3+DN2*bn3*sum_termdev(2, 2)+bn2*(-sum_termdev(2, 1)*DN2+sum_termdev(3, 2)*DN2+DN2*bn3*sum_termexp(1, 1)+DN2*bn3*sum_termexp(2, 1)-DN2*bn3*sum_termexp(2, 2)-DN2*bn3*sum_termexp(3, 2)-DN2*bn3*sum_term(1)+bn3*(sumtermexpzno3+NO30)*DN2+FNO3))*exp(bn2*zbio)-exp(bn2*zox)*(bn2-bn3)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*exp(bn3*zox)+((sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*bn2*exp(bn3*zno3))/((bn3*((DN1*bn1-DN2*bn2)*exp(bn1*zbio)+DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*exp(bn1*zbio)*bn1*(bn2-bn3))*exp(bn3*zox)-DN1*exp(bn1*zbio)*bn1*exp(bn2*zox)*bn2*exp(bn3*zno3));
BN2 = (((-DN1*DN2*bn3*sum_termdev(1, 1)-DN1*sum_termdev(2, 1)*DN2*bn1+DN2^2*bn3*sum_termdev(2, 2)+bn1*(sum_termdev(3, 2)*DN2+DN2*bn3*sum_termexp(1, 1)+DN2*bn3*sum_termexp(2, 1)-DN2*bn3*sum_termexp(2, 2)-DN2*bn3*sum_termexp(3, 2)-DN2*bn3*sum_term(1)+bn3*(sumtermexpzno3+NO30)*DN2+FNO3)*DN1)*exp(bn3*zox)+DN1*exp(bn3*zno3)*bn1*(sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3))*exp(bn1*zbio)+DN2*exp(bn3*zox)*bn3*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))/((((bn3*(DN1*bn1-DN2*bn2)*exp(bn2*zbio)+DN1*exp(bn2*zox)*bn1*(bn2-bn3))*exp(bn3*zox)-DN1*exp(bn2*zox)*exp(bn3*zno3)*bn1*bn2)*exp(bn1*zbio)+DN2*exp(bn3*zox)*exp(bn2*zbio)*bn2*bn3)*DN2);
BN3 = (((-DN1*sum_termdev(2, 1)*DN2*bn1+DN1*DN2*bn1*sum_termdev(3, 2)-DN1*DN2*bn2*sum_termdev(1, 1)+DN2^2*bn2*sum_termdev(2, 2)+bn1*(DN2*bn2*sum_termexp(1, 1)+DN2*bn2*sum_termexp(2, 1)-DN2*bn2*sum_termexp(2, 2)-DN2*bn2*sum_termexp(3, 2)-sum_term(1)*DN2*bn2+bn2*(sumtermexpzno3+NO30)*DN2+FNO3)*DN1)*exp(bn2*zox)+(sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*(DN1*bn1-DN2*bn2)*exp(bn2*zbio))*exp(bn1*zbio)+((sum_termdev(2, 1)*DN2-sum_termdev(3, 2)*DN2-FNO3)*exp(bn2*zbio)+exp(bn2*zox)*(DN1*sum_termdev(1, 1)-sum_termdev(2, 2)*DN2))*bn2*DN2)/(((bn1*DN1*((bn2-bn3)*exp(bn3*zox)-exp(bn3*zno3)*bn2)*exp(bn2*zox)+exp(bn3*zox)*exp(bn2*zbio)*bn3*(DN1*bn1-DN2*bn2))*exp(bn1*zbio)+DN2*exp(bn3*zox)*exp(bn2*zbio)*bn2*bn3)*DN2);

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zox; ztemp(3)=zno3;
    Atemp(1)=AN1; Atemp(2)=AN2; Atemp(3)=AN3;
    Btemp(1)=BN1; Btemp(2)=BN2; Btemp(3)=BN3;
    atemp(1)=0; atemp(2)=0; atemp(3)=0;
    btemp(1)=bn1; btemp(2)=bn2; btemp(3)=bn3;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DN1;
    conc0temp=NO30;
    calconc;
    F_NO3=F_temp;
    NO3=conc;
end

end

        