% Solve O2

%reactive terms: OM degradation (-) and nitrification (-)
reac1=-OC-2*gamma*NC1;
reac2=-OC-2*gamma*NC2;
ktemp=0;

%define exponents
bO21=w/DO21;
bO22=w/DO22;

%_________________________________________________________________________
% CASE 1 SUPPOSE ZOX<ZBIO: FIND ZOX
% -DO21*(dO2/dz)(zox)=FO2(zox)
%  => -DO21*(BO21*bO21*exp(bO21*zox)+sumtermdevzox)=FO2(zox)
%_________________________________________________________________________

j=1; ztemp=zbio-1; ztemp1=0; Dtemp=DO21;

calcterm;

BO21=@(zox)(-O20+sum_term(j)...
     -term(1,1)*exp(-beta(1,1)*zox)...
     -term(2,1)*exp(-beta(2,1)*zox)...
     -term(3,1)*exp(-beta(3,1)*zox)...
     -term(4,1)*exp(-beta(4,1)*zox)...
     -term(5,1)*exp(-beta(5,1)*zox)...
     -term(6,1)*exp(-beta(6,1)*zox))/(exp(bO21*zox)-1);
 
sumtermdevzox=@(zox) sum(-term(:,j).*beta(:,j).*exp(-beta(:,j).*zox));

% Oxydation of reduced species at zox (NEED A RATIO for ODU! and add NH4
% adsporption!
reacf1=k1*(0.5*OC+2*gamma*NC1);
reacf2=k2*(0.5*OC+2*gamma*NC2);

%FLUX of NH4 and Reduced species from ZOX to ZBIO
flux1=@(zox)-(A11*exp(a11*zox)*a12*b11*b12*reacf1-A11*exp(b11*zox)*a11*a12*b12*reacf1-A11*exp(a11*zbio)*a12*b11*b12*reacf1...
    +A11*exp(b11*zbio)*a11*a12*b12*reacf1+A12*exp(a12*zox)*a11*b11*b12*reacf2-A12*exp(b12*zox)*a11*a12*b11*reacf2...
    -A12*exp(a12*zbio)*a11*b11*b12*reacf2+A12*exp(b12*zbio)*a11*a12*b11*reacf2+C01*exp(b11*zox)*a11*a12*b12*reacf1...
    -C01*exp(b11*zbio)*a11*a12*b12*reacf1+C02*exp(b12*zox)*a11*a12*b11*reacf2-C02*exp(b12*zbio)*a11*a12*b11*reacf2)...
    /(a11*b11*a12*b12);

%FLUX of NH4 and Reduced species from ZBIO to ZINF
flux2=-(reacf1*A21*exp(a21*zbio)*a22-reacf1*A21*exp(a21*zinf)*a22...
    +reacf2*A22*exp(a22*zbio)*a21-reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

FO2=@(zox)flux1(zox)+flux2;

fun=@(zox)-por*DO21*(BO21(zox)*bO21*exp(bO21*zox)+sumtermdevzox(zox))-FO2(zox);

zox=fzero(fun,[1e-10 zinf])

zox(zox<0)=0;

if (zox<=zbio)
% CALCULATE BOUDARY CONDITIONS

BO21=(-O20+sum_term...
             -term(1,1)*exp(-beta(1,1)*zox)...
             -term(2,1)*exp(-beta(2,1)*zox)...
             -term(3,1)*exp(-beta(3,1)*zox)...
             -term(4,1)*exp(-beta(4,1)*zox)...
             -term(5,1)*exp(-beta(5,1)*zox)...
             -term(6,1)*exp(-beta(6,1)*zox))/(exp(bO21*zox)-1);
         
AO21=O20-BO21-(term(1,1)+term(2,1)+term(3,1)+term(4,1)+term(5,1)+term(6,1));
     
if calcconc==1
    ztemp(1)=zox; 
    Atemp(1)=AO21; 
    Btemp(1)=BO21; 
    atemp(1)=0; 
    btemp(1)=bO21; 
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DO21;
    conc0temp=O20;
    calconc; % Calculate concentration profiles and fluxes
    O2=conc;
    F_O2=F_temp; 
end

else
    
%_________________________________________________________________________
% CASE 2 SUPPOSE ZOX>ZBIO
% -DO22*(dO2/dz)(zox)=FO2(zox)
%  => BO22*bO22*exp(bO22*zox)+sumtermdevzox=FO2(zox)
%_________________________________________________________________________

    j=1; ztemp=zbio; ztemp1=0; Dtemp=DO21; calcterm;
    j=2; ztemp=zbio+1; ztemp1= zbio; Dtemp=DO22; calcterm; 
    
    % FIND NEW ZOX
    sumtermexpzox=@(zox) sum(term(:,2).*exp(-beta(:,2).*zox));
    sumtermdevzox=@(zox) sum(-term(:,2).*beta(:,2).*exp(-beta(:,2).*zox));
    
    BO22=@(zox) (sum_termexp(1,1)*DO21*bO21*exp(bO21*zbio)...
            -sum_term(1)*DO21*bO21*exp(bO21*zbio)...
            +O20*DO21*bO21*exp(bO21*zbio)...
            -sum_termexp(2,2)*DO21*bO21*exp(bO21*zbio)...
            +sumtermexpzox(zox)*DO21*bO21*exp(bO21*zbio)...
            +DO21*sum_termdev(1,1)...
            -DO22*sum_termdev(2,2)...
            -exp(bO21*zbio)*DO21*sum_termdev(1,1)...
            +exp(bO21*zbio)*DO22*sum_termdev(2,2))...
            /(DO22*bO22*exp(bO22*zbio)...
            -DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)...
            -exp(bO22*zox)*DO21*bO21*exp(bO21*zbio)...
            +exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio));
        
    %FLUX of NH4 and Reduced species from ZOX to ZINF
    
    FO2=@(zox)-(reacf1*A21*exp(a21*zox)*a22-reacf1*A21*exp(a21*zinf)*a22...
        +reacf2*A22*exp(a22*zox)*a21-reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

    fun=@(zox)-por*DO22*(BO22(zox)*bO22*exp(bO22*zox)+sumtermdevzox(zox))-FO2(zox);

    zox=fzero(fun,[1e-10 zinf]) 
    
    %define integration constants and parameters
            
    sumtermexpzox=sum(term(:,2).*exp(-beta(:,2).*zox));
    sumtermdevzox=sum(-term(:,2).*beta(:,2).*exp(-beta(:,2).*zox));
    
    BO21=-(-DO22*bO22*exp(bO22*zbio)*sum_termexp(1,1)+DO22*bO22*exp(bO22*zbio)*sum_term(1)-DO22*bO22*exp(bO22*zbio)*O20+DO22*bO22*exp(bO22*zbio)*sum_termexp(2,2)-DO22*bO22*exp(bO22*zbio)*sumtermexpzox-DO21*sum_termdev(1,1)*exp(bO22*zox)+DO21*sum_termdev(1,1)*exp(bO22*zbio)+DO22*sum_termdev(2,2)*exp(bO22*zox)-DO22*sum_termdev(2,2)*exp(bO22*zbio))/(DO22*bO22*exp(bO22*zbio)-DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)-exp(bO22*zox)*DO21*bO21*exp(bO21*zbio)+exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio));
    AO21=(-DO22*bO22*exp(bO22*zbio)*sum_termexp(1,1)+DO22*bO22*exp(bO22*zbio)*sum_termexp(2,2)-DO22*bO22*exp(bO22*zbio)*sumtermexpzox-DO21*sum_termdev(1,1)*exp(bO22*zox)+DO21*sum_termdev(1,1)*exp(bO22*zbio)+DO22*sum_termdev(2,2)*exp(bO22*zox)-DO22*sum_termdev(2,2)*exp(bO22*zbio)+sum_term(1)*DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)+exp(bO22*zox)*sum_term(1)*DO21*bO21*exp(bO21*zbio)-sum_term(1)*exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio)-O20*DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)-exp(bO22*zox)*O20*DO21*bO21*exp(bO21*zbio)+O20*exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio))/(DO22*bO22*exp(bO22*zbio)-DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)-exp(bO22*zox)*DO21*bO21*exp(bO21*zbio)+exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio));
    BO22=(sum_termexp(1,1)*DO21*bO21*exp(bO21*zbio)-sum_term(1)*DO21*bO21*exp(bO21*zbio)+O20*DO21*bO21*exp(bO21*zbio)-sum_termexp(2,2)*DO21*bO21*exp(bO21*zbio)+sumtermexpzox*DO21*bO21*exp(bO21*zbio)+DO21*sum_termdev(1,1)-DO22*sum_termdev(2,2)-exp(bO21*zbio)*DO21*sum_termdev(1,1)+exp(bO21*zbio)*DO22*sum_termdev(2,2))/(DO22*bO22*exp(bO22*zbio)-DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)-exp(bO22*zox)*DO21*bO21*exp(bO21*zbio)+exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio));
    AO22=-(exp(bO22*zox)*sum_termexp(1,1)*DO21*bO21*exp(bO21*zbio)-exp(bO22*zox)*sum_term(1)*DO21*bO21*exp(bO21*zbio)+exp(bO22*zox)*O20*DO21*bO21*exp(bO21*zbio)-exp(bO22*zox)*sum_termexp(2,2)*DO21*bO21*exp(bO21*zbio)+DO21*sum_termdev(1,1)*exp(bO22*zox)-DO22*sum_termdev(2,2)*exp(bO22*zox)-exp(bO22*zox)*exp(bO21*zbio)*DO21*sum_termdev(1,1)+exp(bO22*zox)*exp(bO21*zbio)*DO22*sum_termdev(2,2)+DO22*bO22*exp(bO22*zbio)*sumtermexpzox-sumtermexpzox*DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)+sumtermexpzox*exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio))/(DO22*bO22*exp(bO22*zbio)-DO22*bO22*exp(bO22*zbio)*exp(bO21*zbio)-exp(bO22*zox)*DO21*bO21*exp(bO21*zbio)+exp(bO22*zbio)*DO21*bO21*exp(bO21*zbio));

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zox;
    Atemp(1)=AO21; Atemp(2)=AO22;
    Btemp(1)=BO21; Btemp(2)=BO22;
    atemp(1)=0; atemp(2)=0;
    btemp(1)=bO21; btemp(2)=bO22;
    Qtemp(1:4)=0;
    conclim=0;
    Dtemp=DO21;
    conc0temp=O20;
    calconc;
    O2=conc;
    F_O2=F_temp;
end

end

