% Solve NH4

%_________________________________________________________________________________________________________________________
%NH4
%reaction-transport equation:
%                                   dNH4/dt=D*(d^2NH4/dz^2)-w*NH4-sum(REAC(z)))
%__________________________________________________________________________________________________________________________

K=(1-gamma)/(1+NH4ads); % Nitrification and adsorption
J=1/(1+NH4ads);         % Adsorption

if (zox<=zbio) && (zbio<=zno3)
%CASE 1 ZOX<ZBIO<ZNO3

%LAYER 1 reactive terms: Aerobic degradation (+) Nitrification (-) Adsorption (-)
j=1; ztemp=zox; ztemp1=0;
reac1=K*NC1;
reac2=K*NC2;
ktemp=0;
Dtemp=DNH41;
calcterm;

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: /

%LAYER 4 reactive terms: Methanogenesis (+) Adsorption (-)
j=4; ztemp=zinf; ztemp1=zno3;
reac1=J*NC1;
reac2=J*NC2;
ktemp=0;
Dtemp=DNH42;
calcterm;

%define exponents
bNH41=w/DNH41;
bNH42=w/DNH41;
bNH43=w/DNH42;
bNH44=w/DNH42;

%Flux of CH4 through ZOX

reacf1=J*k1*NC1;
reacf2=J*k2*NC2;

flux=-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zno3)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22); % * 1/POR ????

cstf=1-gamma;
  
 ANH41 = ((-(DNH41*bNH41*(sum_term(1)-NH40)*exp(bNH41*zox)-DNH41*sum_termdev(1,1)+cstf*flux)*exp(bNH43*zno3)*exp(bNH42*zbio)-DNH42*exp(bNH43*zbio)*exp(bNH42*zox)*sum_termdev(4,2))*exp(bNH44*zinf)+DNH42*exp(bNH44*zno3)*exp(bNH42*zox)*exp(bNH43*zbio)*sum_termdev(4,1))/(DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zbio)*exp(bNH43*zno3)*exp(bNH44*zinf));
 ANH42 = (((-(((sum_term(1)-sum_termexp(1,1)-NH40)*bNH41+sum_termdev(1,1))*DNH41-cstf*flux)*exp(bNH43*zno3)*bNH42*exp(bNH42*zbio)-sum_termdev(4,2)*exp(bNH42*zox)*exp(bNH43*zbio)*DNH42*(bNH41-bNH42))*exp(bNH41*zox)+(exp(bNH43*zno3)*(DNH41*sum_termdev(1,1)-cstf*flux)*exp(bNH42*zbio)-DNH42*exp(bNH43*zbio)*exp(bNH42*zox)*sum_termdev(4,2))*bNH42)*exp(bNH44*zinf)+DNH42*((bNH41-bNH42)*exp(bNH41*zox)+bNH42)*sum_termdev(4,1)*exp(bNH42*zox)*exp(bNH44*zno3)*exp(bNH43*zbio))/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH42*zbio)*bNH42*exp(bNH43*zno3)*exp(bNH44*zinf));
 ANH43 = ((((-bNH41*sum_termdev(4,2)*(DNH41*bNH42-DNH42*bNH43)*exp(bNH43*zbio)-(DNH41*(sum_term(1)-sum_termexp(1,1)-NH40)*bNH41+DNH41*sum_termdev(1,1)-cstf*flux)*bNH43*bNH42*exp(bNH43*zno3))*exp(bNH42*zbio)-bNH43*DNH42*exp(bNH42*zox)*exp(bNH43*zbio)*sum_termdev(4,2)*(bNH41-bNH42))*exp(bNH44*zinf)+(bNH41*(DNH41*bNH42-DNH42*bNH43)*exp(bNH42*zbio)+bNH43*DNH42*exp(bNH42*zox)*(bNH41-bNH42))*sum_termdev(4,1)*exp(bNH44*zno3)*exp(bNH43*zbio))*exp(bNH41*zox)+((exp(bNH43*zno3)*(DNH41*sum_termdev(1,1)-cstf*flux)*exp(bNH42*zbio)-DNH42*exp(bNH43*zbio)*exp(bNH42*zox)*sum_termdev(4,2))*exp(bNH44*zinf)+DNH42*exp(bNH44*zno3)*exp(bNH42*zox)*exp(bNH43*zbio)*sum_termdev(4,1))*bNH43*bNH42)/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH42*zbio)*bNH42*exp(bNH43*zno3)*bNH43*exp(bNH44*zinf));
 ANH44 = (((-bNH44*(((DNH41*(sum_term(1)-sum_termexp(1,1)+sum_termexp(4,2)-NH40)*bNH41+DNH41*sum_termdev(1,1)-cstf*flux)*bNH43-bNH41*sum_termdev(4,2)*DNH41)*bNH42*exp(bNH43*zno3)+bNH41*sum_termdev(4,2)*(DNH41*bNH42-DNH42*bNH43)*exp(bNH43*zbio))*exp(bNH44*zinf)+sum_termdev(4,1)*bNH41*exp(bNH44*zno3)*(bNH42*DNH41*(bNH43-bNH44)*exp(bNH43*zno3)+bNH44*exp(bNH43*zbio)*(DNH41*bNH42-DNH42*bNH43)))*exp(bNH42*zbio)+bNH43*bNH44*exp(bNH42*zox)*exp(bNH43*zbio)*DNH42*(exp(bNH44*zno3)*sum_termdev(4,1)-exp(bNH44*zinf)*sum_termdev(4,2))*(bNH41-bNH42))*exp(bNH41*zox)+(exp(bNH44*zinf)*exp(bNH43*zno3)*(DNH41*sum_termdev(1,1)-cstf*flux)*exp(bNH42*zbio)+exp(bNH42*zox)*exp(bNH43*zbio)*DNH42*(exp(bNH44*zno3)*sum_termdev(4,1)-exp(bNH44*zinf)*sum_termdev(4,2)))*bNH44*bNH43*bNH42)/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH42*zbio)*bNH42*exp(bNH43*zno3)*bNH43*exp(bNH44*zinf)*bNH44); 
 BNH41 = ((-exp(bNH43*zno3)*(DNH41*sum_termdev(1,1)-cstf*flux)*exp(bNH42*zbio)+DNH42*exp(bNH43*zbio)*exp(bNH42*zox)*sum_termdev(4,2))*exp(bNH44*zinf)-DNH42*exp(bNH44*zno3)*exp(bNH42*zox)*exp(bNH43*zbio)*sum_termdev(4,1))/(DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zbio)*exp(bNH43*zno3)*exp(bNH44*zinf));
 BNH42 = DNH42*(exp(bNH44*zinf)*sum_termdev(4,2)-exp(bNH44*zno3)*sum_termdev(4,1))*exp(bNH43*zbio)/(DNH41*exp(bNH42*zbio)*bNH42*exp(bNH43*zno3)*exp(bNH44*zinf));
 BNH43 = (exp(bNH44*zinf)*sum_termdev(4,2)-exp(bNH44*zno3)*sum_termdev(4,1))/(exp(bNH43*zno3)*bNH43*exp(bNH44*zinf));
 BNH44 = -sum_termdev(4,1)/(exp(bNH44*zinf)*bNH44);  
 
 if calcconc==1
    ztemp(1)=zox; ztemp(2)=zbio; ztemp(3)=zno3; ztemp(4)=zinf;
    Atemp(1)=ANH41; Atemp(2)=ANH42; Atemp(3)=ANH43; Atemp(4)=ANH44;
    Btemp(1)=BNH41; Btemp(2)=BNH42; Btemp(3)=BNH43; Btemp(4)=BNH44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bNH41; btemp(2)=bNH42; btemp(3)=bNH43; btemp(4)=bNH44;
    Qtemp(1:4)=0;
    Dtemp=DNH41*J;
    conc0temp=NH40;
    calconc;
    F_NH4=F_temp;
    NH4=conc;
end

 elseif (zox<=zno3) && (zno3<=zbio)
        
%CASE 2 ZOX<ZNO3<ZBIO

%LAYER 1 reactive terms: Aerobic degradation (+) Nitrification (-) Adsorption (-)
j=1; ztemp=zox; ztemp1=0;
reac1=K*NC1;
reac2=K*NC2;
ktemp=0;
Dtemp=DNH41;
calcterm;

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms:  Methanogenesis (+) Adsorption (-)
j=3; ztemp=zbio; ztemp1=zno3;
reac1=J*NC1;
reac2=J*NC2;
ktemp=0;
Dtemp=DNH41;
calcterm;

%LAYER 4 reactive terms: Methanogenesis (+) Adsorption (-)
j=4; ztemp=zinf; ztemp1=zbio;
reac1=J*NC1;
reac2=J*NC2;
ktemp=0;
Dtemp=DNH42;
calcterm;

bNH41=w/DNH41;
bNH42=w/DNH41;
bNH43=w/DNH41;
bNH44=w/DNH42;

reacf1=J*k1*NC1;
reacf2=J*k2*NC2;

flux1=-(A11*exp(a11*zno3)*a12*b11*b12*reacf1-A11*exp(b11*zno3)*a11*a12*b12*reacf1-A11*exp(a11*zbio)*a12*b11*b12*reacf1...
    +A11*exp(b11*zbio)*a11*a12*b12*reacf1+A12*exp(a12*zno3)*a11*b11*b12*reacf2-A12*exp(b12*zno3)*a11*a12*b11*reacf2...
    -A12*exp(a12*zbio)*a11*b11*b12*reacf2+A12*exp(b12*zbio)*a11*a12*b11*reacf2+C01*exp(b11*zno3)*a11*a12*b12*reacf1...
    -C01*exp(b11*zbio)*a11*a12*b12*reacf1+C02*exp(b12*zno3)*a11*a12*b11*reacf2-C02*exp(b12*zbio)*a11*a12*b11*reacf2)...
    /(a11*b11*a12*b12);

flux2=-(reacf1*A21*exp(a21*zbio)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zbio)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22);

flux=1/por*(flux1+flux2);
cstf=1-gamma;

ANH41 = (NH40*DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zinf)-sum_term(1)*DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zinf)+DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)-exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux)/(DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zinf));
ANH42 = (bNH42*exp(bNH41*zox)*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux+DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)*exp(bNH41*zox)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)*exp(bNH41*zox)*bNH41-bNH42*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)+bNH42*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)-bNH42*exp(bNH41*zox)*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)+bNH42*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)-bNH42*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)+DNH41*NH40*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*sum_term(1)*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*sum_termexp(1,1)*exp(bNH41*zox)*bNH41+bNH42*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-bNH42*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)+bNH42*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)-bNH42*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)+bNH42*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)-bNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux)/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42);
ANH43 = (DNH41*NH40*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_term(1)*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_termexp(1,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_termexp(3,2)*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termdev(4,2)*exp(bNH41*zox)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH43*sum_termdev(4,1)*exp(bNH41*zox)*bNH41-DNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH42*sum_termdev(4,2)*exp(bNH41*zox)*bNH41+DNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH43*sum_termdev(4,2)*exp(bNH41*zox)*bNH41+DNH42*exp(bNH42*zno3)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH42*sum_termdev(4,1)*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zno3)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH43*sum_termdev(4,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*bNH43*sum_termdev(3,2)*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH43*sum_termdev(3,2)*exp(bNH41*zox)*bNH41-bNH42*bNH43*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)+bNH42*bNH43*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)-bNH42*bNH43*exp(bNH41*zox)*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)+bNH42*bNH43*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)-bNH42*bNH43*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)+bNH42*bNH43*exp(bNH41*zox)*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux+DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termdev(3,1)*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH42*sum_termdev(3,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH43*sum_termdev(3,1)*exp(bNH41*zox)*bNH41+bNH42*bNH43*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-bNH42*bNH43*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)+bNH42*bNH43*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)-bNH42*bNH43*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)+bNH42*bNH43*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)-bNH42*bNH43*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux)/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43);
ANH44 = (DNH42*exp(bNH42*zno3)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH42*sum_termdev(4,1)*bNH44*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zno3)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH43*sum_termdev(4,1)*bNH44*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH44*sum_termdev(3,1)*exp(bNH41*zox)*bNH41+DNH41*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zbio)*bNH42*bNH43*sum_termdev(4,1)*exp(bNH41*zox)*bNH41+DNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH44*sum_termdev(4,2)*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zbio)*bNH42*bNH44*sum_termdev(4,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*bNH43*sum_termdev(3,2)*bNH44*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH43*sum_termdev(3,2)*bNH44*exp(bNH41*zox)*bNH41-bNH42*bNH43*bNH44*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)+bNH42*bNH43*bNH44*exp(bNH41*zox)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)-bNH42*bNH43*bNH44*exp(bNH41*zox)*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)+bNH42*bNH43*bNH44*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)-bNH42*bNH43*bNH44*exp(bNH41*zox)*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)+bNH42*bNH43*bNH44*exp(bNH41*zox)*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux+DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termdev(3,1)*bNH44*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH42*sum_termdev(3,1)*bNH44*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH43*sum_termdev(3,1)*bNH44*exp(bNH41*zox)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termdev(4,2)*bNH44*exp(bNH41*zox)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*bNH43*sum_termdev(4,1)*bNH44*exp(bNH41*zox)*bNH41-DNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH42*sum_termdev(4,2)*bNH44*exp(bNH41*zox)*bNH41+DNH42*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zno3)*bNH43*sum_termdev(4,2)*bNH44*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_termexp(3,2)*bNH44*exp(bNH41*zox)*bNH41+DNH41*NH40*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*bNH44*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_term(1)*bNH44*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*sum_termexp(1,1)*bNH44*exp(bNH41*zox)*bNH41+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*bNH44*sum_termexp(3,1)*exp(bNH41*zox)*bNH41-DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*bNH44*sum_termexp(4,2)*exp(bNH41*zox)*bNH41+bNH42*bNH43*bNH44*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-bNH42*bNH43*bNH44*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)+bNH42*bNH43*bNH44*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)-bNH42*bNH43*bNH44*DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)+bNH42*bNH43*bNH44*DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)-bNH42*bNH43*bNH44*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux)/(exp(bNH41*zox)*bNH41*DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*bNH42*bNH43*bNH44);
BNH41 = -(DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zbio)*sum_termdev(3,2)+DNH41*exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*sum_termdev(1,1)-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2)+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)-exp(bNH44*zinf)*exp(bNH42*zno3)*exp(bNH43*zbio)*cstf*flux)/(DNH41*exp(bNH41*zox)*bNH41*exp(bNH42*zno3)*exp(bNH43*zbio)*exp(bNH44*zinf));
BNH42 = (sum_termdev(3,2)*DNH41*exp(bNH44*zinf)*exp(bNH43*zbio)-DNH41*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(3,1)-DNH42*exp(bNH43*zno3)*exp(bNH44*zbio)*sum_termdev(4,1)+DNH42*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(4,2))/(DNH41*exp(bNH43*zbio)*exp(bNH44*zinf)*exp(bNH42*zno3)*bNH42);
BNH43 = -(DNH41*sum_termdev(3,1)*exp(bNH44*zinf)-DNH42*sum_termdev(4,2)*exp(bNH44*zinf)+sum_termdev(4,1)*DNH42*exp(bNH44*zbio))/(DNH41*exp(bNH43*zbio)*bNH43*exp(bNH44*zinf));
BNH44 = -sum_termdev(4,1)/(exp(bNH44*zinf)*bNH44);

 if calcconc==1
    ztemp(1)=zox; ztemp(2)=zno3; ztemp(3)=zbio; ztemp(4)=zinf;
    Atemp(1)=ANH41; Atemp(2)=ANH42; Atemp(3)=ANH43; Atemp(4)=ANH44;
    Btemp(1)=BNH41; Btemp(2)=BNH42; Btemp(3)=BNH43; Btemp(4)=BNH44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bNH41; btemp(2)=bNH42; btemp(3)=bNH43; btemp(4)=bNH44;
    Qtemp(1:4)=0;
    Dtemp=DNH41*J;
    conc0temp=NH40;
    calconc;
    F_NH4=F_temp;
    NH4=conc;
end

elseif (zbio<=zox && zox<=zno3)  
%CASE 3 zbio<zox<zno3

%LAYER 1 reactive terms: Aerobic degradation (+) Nitrification (-) Adsorption (-)
j=1; ztemp=zbio; ztemp1=0;
reac1=K*NC1;
reac2=K*NC2;
ktemp=0;
Dtemp=DNH41;
calcterm;

%LAYER 2 reactive terms: Aerobic degradation (+) Nitrification (-) Adsorption (-)

j=2; ztemp=zox; ztemp1=zbio;
reac1=K*NC1;
reac2=K*NC2;
ktemp=0;
Dtemp=DNH42;
calcterm;

%LAYER 3 reactive terms: /

%LAYER 4 reactive terms: Methanogenesis (+) Adsorption (-)
j=4; ztemp=zinf; ztemp1=zno3;
reac1=J*NC1;
reac2=J*NC2;
ktemp=0;
Dtemp=DNH42;
calcterm;

bNH41=w/DNH41;
bNH42=w/DNH42;
bNH43=w/DNH42;
bNH44=w/DNH42;

reacf1=J*k1*NC1;
reacf2=J*k2*NC2;

flux=-1/por*(reacf1*A21*exp(a21*zno3)*a22-reacf1*A21*exp(a21*zinf)*a22+reacf2*A22*exp(a22*zno3)*a21...
    -reacf2*A22*exp(a22*zinf)*a21)/(a21*a22); % * 1/POR ????

cstf=1-gamma;

ANH41 = (NH40*DNH41*exp(bNH41*zbio)*bNH41*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zinf)-sum_term(1)*DNH41*exp(bNH41*zbio)*bNH41*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zinf)+DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)-DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)+DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)+DNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)-exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux)/(DNH41*exp(bNH41*zbio)*bNH41*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zinf));
ANH42 = (-DNH42^2*bNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)+DNH42^2*bNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)+DNH42^2*bNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)-DNH42^2*bNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)+DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)+DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)-DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)-DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)+DNH42*bNH42*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)-DNH42*bNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux+exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termexp(1,1)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*NH40*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*sum_term(1)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termexp(2,2)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41-DNH42*bNH42*exp(bNH41*zbio)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)+DNH42*bNH42*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux-DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*DNH42*exp(bNH42*zbio)*sum_termdev(2,1)*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*exp(bNH42*zbio)*cstf*flux*DNH41*exp(bNH41*zbio)*bNH41)/(DNH41*exp(bNH41*zbio)*bNH41*exp(bNH44*zinf)*exp(bNH43*zno3)*DNH42*exp(bNH42*zox)*bNH42);
ANH43 = (bNH43*DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)+bNH43*DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)-bNH43*DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)-bNH43*DNH42^2*bNH42*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)+bNH43*DNH42*bNH42*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)-bNH43*DNH42*bNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux-bNH43*DNH42^2*bNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)+bNH43*DNH42^2*bNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)+bNH43*DNH42^2*bNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)-bNH43*DNH42^2*bNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)-bNH43*DNH42*bNH42*exp(bNH41*zbio)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)+bNH43*DNH42*bNH42*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux-DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zinf)*bNH42*sum_termdev(4,2)*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zinf)*bNH43*sum_termdev(4,2)*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zno3)*bNH42*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zno3)*bNH43*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*bNH43*sum_termdev(4,2)*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*bNH43*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zbio)*sum_termdev(2,1)*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zox)*sum_termdev(2,1)*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*exp(bNH42*zox)*cstf*flux*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*exp(bNH42*zbio)*cstf*flux*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(1,1)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*NH40*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_term(1)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(2,2)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(2,1)*DNH42*exp(bNH42*zox)*bNH42*DNH41*exp(bNH41*zbio)*bNH41)/(DNH41*exp(bNH41*zbio)*bNH41*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zox)*bNH42);
ANH44 = (-bNH43*DNH42^2*bNH42*bNH44*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)+bNH43*DNH42^2*bNH42*bNH44*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)+bNH43*DNH42^2*bNH42*bNH44*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)-bNH43*DNH42^2*bNH42*bNH44*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)+bNH43*DNH42^2*bNH42*bNH44*exp(bNH41*zbio)*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)+bNH43*DNH42^2*bNH42*bNH44*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)-bNH43*DNH42^2*bNH42*bNH44*exp(bNH41*zbio)*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)-bNH43*DNH42^2*bNH42*bNH44*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)+bNH43*DNH42*bNH42*bNH44*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)-bNH43*DNH42*bNH42*bNH44*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*NH40*DNH42*exp(bNH42*zox)*bNH42*bNH44*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_term(1)*DNH42*exp(bNH42*zox)*bNH42*bNH44*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(2,2)*DNH42*exp(bNH42*zox)*bNH42*bNH44*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(2,1)*DNH42*exp(bNH42*zox)*bNH42*bNH44*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH42*bNH43*bNH44*sum_termexp(4,2)*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*sum_termexp(1,1)*DNH42*exp(bNH42*zox)*bNH42*bNH44*DNH41*exp(bNH41*zbio)*bNH41-bNH43*DNH42*bNH42*bNH44*exp(bNH41*zbio)*DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)+bNH43*DNH42*bNH42*bNH44*exp(bNH41*zbio)*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux-DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zinf)*bNH42*sum_termdev(4,2)*bNH44*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zinf)*bNH43*sum_termdev(4,2)*bNH44*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zno3)*bNH42*sum_termdev(4,1)*bNH44*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH43*zox)*exp(bNH44*zno3)*bNH43*sum_termdev(4,1)*bNH44*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*bNH43*sum_termdev(4,2)*bNH44*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*bNH43*sum_termdev(4,1)*bNH44*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH42*bNH44*sum_termdev(4,2)*DNH41*exp(bNH41*zbio)*bNH41+DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zno3)*bNH42*bNH43*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41-DNH42*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zno3)*bNH42*bNH44*sum_termdev(4,1)*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zbio)*sum_termdev(2,1)*bNH44*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zox)*sum_termdev(2,1)*bNH44*DNH41*exp(bNH41*zbio)*bNH41+exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*exp(bNH42*zox)*cstf*flux*bNH44*DNH41*exp(bNH41*zbio)*bNH41-exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*exp(bNH42*zbio)*cstf*flux*bNH44*DNH41*exp(bNH41*zbio)*bNH41)/(DNH41*exp(bNH41*zbio)*bNH41*exp(bNH44*zinf)*exp(bNH43*zno3)*bNH43*DNH42*exp(bNH42*zox)*bNH42*bNH44);
BNH41 = -(DNH41*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(1,1)-DNH42*exp(bNH42*zox)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,2)-DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zinf)*sum_termdev(4,2)+DNH42*exp(bNH43*zox)*exp(bNH42*zbio)*exp(bNH44*zno3)*sum_termdev(4,1)+DNH42*exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)-exp(bNH42*zbio)*exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux)/(DNH41*exp(bNH41*zbio)*bNH41*exp(bNH42*zox)*exp(bNH43*zno3)*exp(bNH44*zinf));
BNH42 = (DNH42*exp(bNH43*zox)*exp(bNH44*zinf)*sum_termdev(4,2)-DNH42*exp(bNH43*zox)*exp(bNH44*zno3)*sum_termdev(4,1)-DNH42*exp(bNH44*zinf)*exp(bNH43*zno3)*sum_termdev(2,1)+exp(bNH44*zinf)*exp(bNH43*zno3)*cstf*flux)/(exp(bNH42*zox)*bNH42*exp(bNH43*zno3)*exp(bNH44*zinf)*DNH42);
BNH43 = (exp(bNH44*zinf)*sum_termdev(4,2)-exp(bNH44*zno3)*sum_termdev(4,1))/(exp(bNH43*zno3)*bNH43*exp(bNH44*zinf));
BNH44 = -sum_termdev(4,1)/(exp(bNH44*zinf)*bNH44) ;

 if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zox; ztemp(3)=zno3; ztemp(4)=zinf;
    Atemp(1)=ANH41; Atemp(2)=ANH42; Atemp(3)=ANH43; Atemp(4)=ANH44;
    Btemp(1)=BNH41; Btemp(2)=BNH42; Btemp(3)=BNH43; Btemp(4)=BNH44;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0;
    btemp(1)=bNH41; btemp(2)=bNH42; btemp(3)=bNH43; btemp(4)=bNH44;
    Qtemp(1:4)=0;
    Dtemp=DNH41*J;
    conc0temp=NH40;
    calconc;
    F_NH4=F_temp;
    NH4=conc;
end
        
end

