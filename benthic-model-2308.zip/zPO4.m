%SOLVE PO4

if (zno3<=zbio)
            
%LAYER 1 reactive terms: OM degradation (+) Sorption
j=1; ztemp=zno3; ztemp1=0;
reac1=1/(1+KPO41)*PC1;
reac2=1/(1+KPO41)*PC2;
ktemp=ksPO4/(1+KPO41);
Dtemp=DPO41/(1+KPO41);
calcterm;
Q1=PO4s;

%LAYER 2 reactive terms: OM degradation (+) Sorption
j=2; ztemp=zbio; ztemp1=zno3;
reac1=1/(1+KPO42)*PC1;
reac2=1/(1+KPO42)*PC2;
ktemp=kaPO4/(1+KPO42);
Dtemp=DPO41/(1+KPO42);
calcterm;
Q2=PO4a;

%LAYER 3 reactive terms: OM degradation (+) Sorption
j=3; ztemp=zinf; ztemp1=zbio;
reac1=1/(1+KPO42)*PC1;
reac2=1/(1+KPO42)*PC2;
ktemp=kaPO4/(1+KPO42);
Dtemp=DPO42/(1+KPO42);
calcterm;
Q3=PO4a;

 %define integration constants and parameters
 aPO41=(w-sqrt(w^2+4*DPO41/(1+KPO41)*ksPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 bPO41=(w+sqrt(w^2+4*DPO41/(1+KPO41)*ksPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 aPO42=(w-sqrt(w^2+4*DPO41/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO41/(1+KPO42));
 bPO42=(w+sqrt(w^2+4*DPO41/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO41/(1+KPO42));
 aPO43=(w-sqrt(w^2+4*DPO42/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO42/(1+KPO42));
 bPO43=(w+sqrt(w^2+4*DPO42/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO42/(1+KPO42));

APO41 = (((aPO42-bPO42)*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*(1+KPO41)*exp(bPO42*zno3)-exp(bPO42*zbio)*(((1+KPO41)*aPO42-bPO41*(1+KPO42))*(Q1+sum_term(1)-PO40)*exp(bPO41*zno3)-(1+KPO41)*(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO42-KPO41*sum_termdev(2,2)+KPO42*sum_termdev(1,1)+sum_termdev(1,1)-sum_termdev(2,2))*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43)))*exp(aPO42*zno3)+(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(bPO42*zno3)*(((1+KPO41)*bPO42-bPO41*(1+KPO42))*(Q1+sum_term(1)-PO40)*exp(bPO41*zno3)-(1+KPO41)*(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO42-KPO41*sum_termdev(2,2)+KPO42*sum_termdev(1,1)+sum_termdev(1,1)-sum_termdev(2,2))*exp(aPO42*zbio))/(-exp(bPO42*zbio)*(((-KPO41-1)*aPO42+bPO41*(1+KPO42))*exp(bPO41*zno3)+((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3))*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*exp(aPO42*zno3)+(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(bPO42*zno3)*exp(aPO42*zbio)*(((-KPO41-1)*bPO42+bPO41*(1+KPO42))*exp(bPO41*zno3)+exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))));
APO42 = ((-exp(bPO42*zbio)*(1+KPO42)*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*(Q1+sum_term(1)-PO40)*(aPO41-bPO41)*exp(bPO41*zno3)+(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*(((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*exp(bPO42*zbio)-exp(bPO42*zno3)*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*((1+KPO41)*bPO42-aPO41*(1+KPO42)))*exp(aPO41*zno3)-exp(bPO41*zno3)*((((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*exp(bPO42*zbio)-exp(bPO42*zno3)*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*((1+KPO41)*bPO42-bPO41*(1+KPO42))))/((-(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*(KPO41*aPO42-KPO42*aPO41-aPO41+aPO42)*exp(aPO42*zno3)*exp(bPO42*zbio)+(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(bPO42*zno3)*exp(aPO42*zbio)*((1+KPO41)*bPO42-aPO41*(1+KPO42)))*exp(aPO41*zno3)-(-(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*exp(aPO42*zno3)*(KPO41*aPO42-KPO42*bPO41+aPO42-bPO41)*exp(bPO42*zbio)+(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(bPO42*zno3)*exp(aPO42*zbio)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*exp(bPO41*zno3));
APO43 = (-((DPO41*(aPO42-bPO42)*(((aPO41-bPO41)*(1+KPO42)*(Q1+sum_term(1)-PO40)*exp(bPO41*zno3)+((-Q1+Q2-sum_termexp(1,1)+sum_termexp(2,2))*aPO41+sum_termdev(1,1))*KPO42+(-Q1+Q2-sum_termexp(1,1)+sum_termexp(2,2))*aPO41-KPO41*sum_termdev(2,2)+sum_termdev(1,1)-sum_termdev(2,2))*exp(aPO41*zno3)+(((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*exp(bPO41*zno3))*exp(bPO42*zbio)+exp(bPO42*zno3)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*(((Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO42-sum_termdev(2,1))*DPO41+sum_termdev(3,2)*DPO42))*exp(aPO42*zbio)-exp(bPO42*zbio)*(((Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO42-sum_termdev(2,1))*DPO41+sum_termdev(3,2)*DPO42)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3))*bPO43*exp(bPO43*zinf)-(exp(bPO42*zno3)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*(DPO41*aPO42-DPO42*bPO43)*exp(aPO42*zbio)-exp(bPO42*zbio)*(DPO41*bPO42-DPO42*bPO43)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3))*sum_termdev(3,1)*exp(bPO43*zbio))/(-(exp(bPO42*zno3)*(DPO41*aPO42-DPO42*aPO43)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*exp(aPO42*zbio)+exp(bPO42*zbio)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO42*zno3))*exp(aPO43*zbio)*bPO43*exp(bPO43*zinf)+(exp(bPO42*zno3)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*(DPO41*aPO42-DPO42*bPO43)*exp(aPO42*zbio)-exp(bPO42*zbio)*(DPO41*bPO42-DPO42*bPO43)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3))*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf));
BPO41 = ((-(aPO42-bPO42)*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*(1+KPO41)*exp(bPO42*zno3)+exp(bPO42*zbio)*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*(Q1+sum_term(1)-PO40)*exp(aPO41*zno3)-(1+KPO41)*(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO42-KPO41*sum_termdev(2,2)+KPO42*sum_termdev(1,1)+sum_termdev(1,1)-sum_termdev(2,2)))*exp(aPO42*zno3)-((Q1+sum_term(1)-PO40)*((1+KPO41)*bPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-(1+KPO41)*(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO42-KPO41*sum_termdev(2,2)+KPO42*sum_termdev(1,1)+sum_termdev(1,1)-sum_termdev(2,2))*exp(bPO42*zno3)*exp(aPO42*zbio)*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43)))/(-exp(bPO42*zbio)*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3)+(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*exp(bPO42*zno3)*exp(aPO42*zbio)*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43)));
BPO42 = (((aPO41-bPO41)*(Q1+sum_term(1)-PO40)*(1+KPO42)*exp(aPO42*zbio)*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(bPO41*zno3)-(((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*aPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(aPO42*zbio)+((1+KPO41)*aPO42-aPO41*(1+KPO42))*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*exp(aPO42*zno3))*exp(aPO41*zno3)+exp(bPO41*zno3)*((((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(aPO42*zbio)-((1+KPO41)*aPO42-bPO41*(1+KPO42))*((sum_termdev(3,1)*DPO42*(aPO43-bPO43)*exp(bPO43*zbio)+exp(bPO43*zinf)*(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*bPO43)*exp(aPO43*zbio)-(DPO42*(Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO43-sum_termdev(2,1)*DPO41+sum_termdev(3,2)*DPO42)*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf))*exp(aPO42*zno3)))/((exp(bPO42*zno3)*(KPO41*bPO42-KPO42*aPO41-aPO41+bPO42)*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(aPO42*zbio)-exp(bPO42*zbio)*((1+KPO41)*aPO42-aPO41*(1+KPO42))*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*exp(aPO42*zno3))*exp(aPO41*zno3)-exp(bPO41*zno3)*((KPO41*bPO42-KPO42*bPO41-bPO41+bPO42)*exp(bPO42*zno3)*(-bPO43*exp(bPO43*zinf)*(DPO41*aPO42-DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*aPO42-DPO42*bPO43))*exp(aPO42*zbio)-exp(bPO42*zbio)*(bPO43*exp(bPO43*zinf)*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO43*zbio)+aPO43*exp(aPO43*zinf)*exp(bPO43*zbio)*(DPO41*bPO42-DPO42*bPO43))*((1+KPO41)*aPO42-bPO41*(1+KPO42))*exp(aPO42*zno3)));
BPO43 = (((DPO41*(aPO42-bPO42)*(((aPO41-bPO41)*(1+KPO42)*(Q1+sum_term(1)-PO40)*exp(bPO41*zno3)+((-Q1+Q2-sum_termexp(1,1)+sum_termexp(2,2))*aPO41+sum_termdev(1,1))*KPO42+(-Q1+Q2-sum_termexp(1,1)+sum_termexp(2,2))*aPO41-KPO41*sum_termdev(2,2)+sum_termdev(1,1)-sum_termdev(2,2))*exp(aPO41*zno3)+(((Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41-sum_termdev(1,1))*KPO42+(Q1-Q2+sum_termexp(1,1)-sum_termexp(2,2))*bPO41+KPO41*sum_termdev(2,2)-sum_termdev(1,1)+sum_termdev(2,2))*exp(bPO41*zno3))*exp(bPO42*zbio)+exp(bPO42*zno3)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*(((Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*aPO42-sum_termdev(2,1))*DPO41+sum_termdev(3,2)*DPO42))*exp(aPO42*zbio)-exp(bPO42*zbio)*(((Q2+sum_termexp(2,1)-sum_termexp(3,2)-Q3)*bPO42-sum_termdev(2,1))*DPO41+sum_termdev(3,2)*DPO42)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3))*aPO43*exp(aPO43*zinf)+sum_termdev(3,1)*exp(aPO43*zbio)*(exp(bPO42*zno3)*(DPO41*aPO42-DPO42*aPO43)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*exp(aPO42*zbio)+exp(bPO42*zbio)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO42*zno3)))/(-(exp(bPO42*zno3)*(DPO41*aPO42-DPO42*aPO43)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*exp(aPO42*zbio)+exp(bPO42*zbio)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*(-DPO41*bPO42+DPO42*aPO43)*exp(aPO42*zno3))*exp(aPO43*zbio)*bPO43*exp(bPO43*zinf)+(exp(bPO42*zno3)*(exp(aPO41*zno3)*((1+KPO41)*bPO42-aPO41*(1+KPO42))-exp(bPO41*zno3)*((1+KPO41)*bPO42-bPO41*(1+KPO42)))*(DPO41*aPO42-DPO42*bPO43)*exp(aPO42*zbio)-exp(bPO42*zbio)*(DPO41*bPO42-DPO42*bPO43)*(((1+KPO41)*aPO42-aPO41*(1+KPO42))*exp(aPO41*zno3)-exp(bPO41*zno3)*((1+KPO41)*aPO42-bPO41*(1+KPO42)))*exp(aPO42*zno3))*exp(bPO43*zbio)*aPO43*exp(aPO43*zinf));

if calcconc==1
    ztemp(1)=zno3; ztemp(2)=zbio; ztemp(3)=zinf;
    Atemp(1)=APO41; Atemp(2)=APO42; Atemp(3)=APO43;
    Btemp(1)=BPO41; Btemp(2)=BPO42; Btemp(3)=BPO43;
    atemp(1)=aPO41; atemp(2)=aPO42; atemp(3)=aPO43;
    btemp(1)=bPO41; btemp(2)=bPO42; btemp(3)=bPO43;
    Qtemp(1)=Q1; Qtemp(2)=Q2; Qtemp(3)=Q3;
    Dtemp=DPO41/(1+KPO41);
    conc0temp=PO40;
    calconc;
    F_PO4=F_temp;
    PO4=conc;
end

else 
%__________________________________________________________________________
% Case 2: zbio<zno3
%__________________________________________________________________________

%LAYER 1 reactive terms: OM degradation (+) Sorption
j=1; ztemp=zbio; ztemp1=0;
reac1=1/(1+KPO41)*PC1;
reac2=1/(1+KPO41)*PC2;
ktemp=ksPO4/(1+KPO41);
Dtemp=DPO41/(1+KPO41);
calcterm;
Q1=PO4s;

%LAYER 2 reactive terms: OM degradation (+) Sorption
j=2; ztemp=zno3; ztemp1=zbio;
reac1=1/(1+KPO41)*PC1;
reac2=1/(1+KPO41)*PC2;
ktemp=ksPO4/(1+KPO41);
Dtemp=DPO42/(1+KPO41);
calcterm;
Q2=PO4s;

%LAYER 3 reactive terms: OM degradation (+) Sorption
j=3; ztemp=zinf; ztemp1=zno3;
reac1=1/(1+KPO42)*PC1;
reac2=1/(1+KPO42)*PC2;
ktemp=kaPO4/(1+KPO42);
Dtemp=DPO42/(1+KPO42);
calcterm;
Q3=PO4a;

 %define integration constants and parameters
 aPO41=(w-sqrt(w^2+4*DPO41/(1+KPO41)*ksPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 bPO41=(w+sqrt(w^2+4*DPO41/(1+KPO41)*ksPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 aPO42=(w-sqrt(w^2+4*DPO42/(1+KPO41)*kaPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 bPO42=(w+sqrt(w^2+4*DPO42/(1+KPO41)*kaPO4/(1+KPO41)))/(2*DPO41/(1+KPO41));
 aPO43=(w-sqrt(w^2+4*DPO42/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO42/(1+KPO42));
 bPO43=(w+sqrt(w^2+4*DPO42/(1+KPO42)*kaPO4/(1+KPO42)))/(2*DPO42/(1+KPO42));

APO41 = (DPO41*bPO41*(Q1-PO40+sum_term(1))*exp(bPO41*zbio)+DPO42*sum_termexp(2, 2)-DPO41*sum_termdev(1, 1))/(DPO41*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41));
APO42 = (-((DPO41*(aPO41-bPO41)*(Q1-PO40+sum_term(1))*exp(bPO41*zbio)+(DPO41*aPO41-DPO42)*sum_termexp(2, 2)-DPO41*(-sum_termdev(1, 1)+aPO41*(Q1-Q2+sum_termexp(1, 1))))*exp(aPO41*zbio)+((-DPO41*bPO41+DPO42)*sum_termexp(2, 2)+(-sum_termdev(1, 1)+bPO41*(Q1-Q2+sum_termexp(1, 1)))*DPO41)*exp(bPO41*zbio))*(-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-bPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-bPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(bPO42*zno3)+exp(bPO42*zbio)*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41*((-sum_termdev(3, 1)*(aPO43-bPO43)*(1+KPO41)*exp(bPO43*zno3)-exp(bPO43*zinf)*bPO43*((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*(sum_termdev(3, 2)+aPO43*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3))))*exp(aPO43*zno3)+exp(bPO43*zno3)*((-KPO42-1)*sum_termdev(2, 1)+(sum_termdev(3, 2)+bPO43*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3))*(1+KPO41))*exp(aPO43*zinf)*aPO43))/((exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*((-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-bPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-bPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(aPO42*zbio)*exp(bPO42*zno3)-(-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-aPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-aPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(aPO42*zno3)*exp(bPO42*zbio))*DPO41);
APO43 = (bPO43*((((DPO41*(aPO41-bPO41)*(Q1-PO40+sum_term(1))*exp(bPO41*zbio)+(DPO41*aPO41-DPO42)*sum_termexp(2, 2)-DPO41*(-sum_termdev(1, 1)+aPO41*(Q1-Q2+sum_termexp(1, 1))))*exp(aPO41*zbio)+((-DPO41*bPO41+DPO42)*sum_termexp(2, 2)+(-sum_termdev(1, 1)+bPO41*(Q1-Q2+sum_termexp(1, 1)))*DPO41)*exp(bPO41*zbio))*(1+KPO42)*(aPO42-bPO42)*exp(bPO42*zno3)-exp(bPO42*zbio)*((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*sum_termdev(3, 2)+aPO42*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3)*(1+KPO42))*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41)*exp(aPO42*zno3)+((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*sum_termdev(3, 2)+bPO42*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3)*(1+KPO42))*exp(bPO42*zno3)*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41*exp(aPO42*zbio))*exp(bPO43*zinf)-exp(bPO43*zno3)*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*(-((1+KPO41)*bPO43-aPO42*(1+KPO42))*exp(bPO42*zbio)*exp(aPO42*zno3)+exp(bPO42*zno3)*((1+KPO41)*bPO43-bPO42*(1+KPO42))*exp(aPO42*zbio))*DPO41*sum_termdev(3, 1))/((exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*(-exp(aPO43*zno3)*(-exp(bPO42*zbio)*(KPO41*aPO43-KPO42*aPO42-aPO42+aPO43)*exp(aPO42*zno3)+exp(aPO42*zbio)*exp(bPO42*zno3)*(KPO41*aPO43-KPO42*bPO42+aPO43-bPO42))*bPO43*exp(bPO43*zinf)+exp(bPO43*zno3)*(-((1+KPO41)*bPO43-aPO42*(1+KPO42))*exp(bPO42*zbio)*exp(aPO42*zno3)+exp(bPO42*zno3)*((1+KPO41)*bPO43-bPO42*(1+KPO42))*exp(aPO42*zbio))*exp(aPO43*zinf)*aPO43)*DPO41);
BPO41 = (-DPO41*aPO41*(Q1-PO40+sum_term(1))*exp(aPO41*zbio)-DPO42*sum_termexp(2, 2)+DPO41*sum_termdev(1, 1))/(DPO41*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41));
BPO42 = (((DPO41*(aPO41-bPO41)*(Q1-PO40+sum_term(1))*exp(bPO41*zbio)+(DPO41*aPO41-DPO42)*sum_termexp(2, 2)-DPO41*(-sum_termdev(1, 1)+aPO41*(Q1-Q2+sum_termexp(1, 1))))*exp(aPO41*zbio)+((-DPO41*bPO41+DPO42)*sum_termexp(2, 2)+(-sum_termdev(1, 1)+bPO41*(Q1-Q2+sum_termexp(1, 1)))*DPO41)*exp(bPO41*zbio))*(-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-aPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-aPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(aPO42*zno3)-((-sum_termdev(3, 1)*(aPO43-bPO43)*(1+KPO41)*exp(bPO43*zno3)-exp(bPO43*zinf)*bPO43*((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*(sum_termdev(3, 2)+aPO43*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3))))*exp(aPO43*zno3)+exp(bPO43*zno3)*((-KPO42-1)*sum_termdev(2, 1)+(sum_termdev(3, 2)+bPO43*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3))*(1+KPO41))*exp(aPO43*zinf)*aPO43)*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41*exp(aPO42*zbio))/(((-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-bPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-bPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(aPO42*zbio)*exp(bPO42*zno3)-(-exp(bPO43*zinf)*bPO43*((1+KPO41)*aPO43-aPO42*(1+KPO42))*exp(aPO43*zno3)+exp(bPO43*zno3)*((1+KPO41)*bPO43-aPO42*(1+KPO42))*exp(aPO43*zinf)*aPO43)*exp(aPO42*zno3)*exp(bPO42*zbio))*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41);
BPO43 = (-((((DPO41*(aPO41-bPO41)*(Q1-PO40+sum_term(1))*exp(bPO41*zbio)+(DPO41*aPO41-DPO42)*sum_termexp(2, 2)-DPO41*(-sum_termdev(1, 1)+aPO41*(Q1-Q2+sum_termexp(1, 1))))*exp(aPO41*zbio)+((-DPO41*bPO41+DPO42)*sum_termexp(2, 2)+(-sum_termdev(1, 1)+bPO41*(Q1-Q2+sum_termexp(1, 1)))*DPO41)*exp(bPO41*zbio))*(1+KPO42)*(aPO42-bPO42)*exp(bPO42*zno3)-exp(bPO42*zbio)*((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*sum_termdev(3, 2)+aPO42*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3)*(1+KPO42))*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41)*exp(aPO42*zno3)+((-KPO42-1)*sum_termdev(2, 1)+(1+KPO41)*sum_termdev(3, 2)+bPO42*(Q2+sum_termexp(2, 1)-sum_termexp(3, 2)-Q3)*(1+KPO42))*exp(bPO42*zno3)*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41*exp(aPO42*zbio))*aPO43*exp(aPO43*zinf)+(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*exp(aPO43*zno3)*(-exp(bPO42*zbio)*((1+KPO41)*aPO43-aPO42*(1+KPO42))*exp(aPO42*zno3)+((1+KPO41)*aPO43-bPO42*(1+KPO42))*exp(bPO42*zno3)*exp(aPO42*zbio))*DPO41*sum_termdev(3, 1))/((exp(bPO43*zno3)*(-exp(bPO42*zbio)*(KPO41*bPO43-KPO42*aPO42-aPO42+bPO43)*exp(aPO42*zno3)+exp(aPO42*zbio)*exp(bPO42*zno3)*(KPO41*bPO43-KPO42*bPO42-bPO42+bPO43))*aPO43*exp(aPO43*zinf)-exp(bPO43*zinf)*exp(aPO43*zno3)*bPO43*(-exp(bPO42*zbio)*((1+KPO41)*aPO43-aPO42*(1+KPO42))*exp(aPO42*zno3)+((1+KPO41)*aPO43-bPO42*(1+KPO42))*exp(bPO42*zno3)*exp(aPO42*zbio)))*(exp(aPO41*zbio)*aPO41-exp(bPO41*zbio)*bPO41)*DPO41);

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zno3; ztemp(3)=zinf;
    Atemp(1)=APO41; Atemp(2)=APO42; Atemp(3)=APO43;
    Btemp(1)=BPO41; Btemp(2)=BPO42; Btemp(3)=BPO43;
    atemp(1)=aPO41; atemp(2)=aPO42; atemp(3)=aPO43;
    btemp(1)=bPO41; btemp(2)=bPO42; btemp(3)=bPO43;
    Qtemp(1)=Q1; Qtemp(2)=Q2; Qtemp(3)=Q3;
    Dtemp=DPO41/(1+KPO41);
    conc0temp=PO40;
    calconc;
    F_PO4=F_temp;
    PO4=conc;
end
end

