




bs1=w/DS1;
bs2=w/DS2;

AS1 = S0;
AS2 = S0;
BS1 = 0;
BS2 = 0;
% 
% AS1 = S0*exp(bs1*zbio)*(DS1*exp(bs2*zbio)*bs1-DS1*exp(bs2*zinf)*bs1-DS2*exp(bs2*zbio)*bs2)/(exp(bs2*zbio)*DS1*exp(bs1*zbio)*bs1-exp(bs2*zinf)*DS1*exp(bs1*zbio)*bs1-DS2*exp(bs2*zbio)*bs2*exp(bs1*zbio)+DS2*exp(bs2*zbio)*bs2);
% AS2 = -DS1*exp(bs1*zbio)*bs1*S0*exp(bs2*zinf)/(exp(bs2*zbio)*DS1*exp(bs1*zbio)*bs1-exp(bs2*zinf)*DS1*exp(bs1*zbio)*bs1-DS2*exp(bs2*zbio)*bs2*exp(bs1*zbio)+DS2*exp(bs2*zbio)*bs2);
% BS1 = DS2*S0*bs2*exp(bs2*zbio)/(exp(bs2*zbio)*DS1*exp(bs1*zbio)*bs1-exp(bs2*zinf)*DS1*exp(bs1*zbio)*bs1-DS2*exp(bs2*zbio)*bs2*exp(bs1*zbio)+DS2*exp(bs2*zbio)*bs2);
% BS2 = DS1*exp(bs1*zbio)*bs1*S0/(exp(bs2*zbio)*DS1*exp(bs1*zbio)*bs1-exp(bs2*zinf)*DS1*exp(bs1*zbio)*bs1-DS2*exp(bs2*zbio)*bs2*exp(bs1*zbio)+DS2*exp(bs2*zbio)*bs2);

for i=1:1001
            z=(i-1)/10;
            if z<=zbio
                Sa(i)=AS1+BS1*exp(bs1*z);
            else
                Sa(i)=AS2+BS2*exp(bs2*z);
            end
end