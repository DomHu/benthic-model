%sediment characteristics
rho_sed=2.5;                                                %sediment density (g/cm3) 
wdepth=2000;
w=10.0^(-0.87478367-0.00043512*wdepth)*3.3; % 0.03;                                                     %burial velocity  (cm/yr)

zbio=10;                                                     %bioturbation depth (cm)
zinf=100;                                                  %Inifinity (cm)
Dbio=3;                                                     %bioturbation coefficient (cm2/yr)
por=0.8;                                                    %porosity (-)
tort=3.0;                                                   %tortuosity (-)
irrigationFactor=1.0;                                       %irrigation factor (-)    
dispFactor=por^(tort-1.0)*irrigationFactor;                 %dispersion factor (-)

%bottom water concentrations
T=20.0;                                                     %temperature (degree C)
C01=0.1/12*rho_sed;                                         %TOC concentration at SWI (mol/cm3)
C02=0.1/12*rho_sed;                                         %TOC concentration at SWI (mol/cm3)
O20=900.0e-8;                                               %O2  concentration at SWI (mol/cm3)
SO40=8000.0e-9;                                             %SO4 concentration at SWI (mol/cm3)
H2S0=0.0e-9;                                                %H2S concentration at SWI (mol/cm3)
DIC0=2000.0e-9;                                             %DIC concentration at SWI (mol/cm3)                                             
ALK0=2400.0e-9;                                             %ALK concentration at SWI (mol/cm3)
NO30=50.0e-9;                                               %NO3 concentration at SWI (mol/cm3)
NH40=100.0e-9;                                              %NH4 concentration at SWI (mol/cm3)
PO40=5e-9;                                                  %PO4 concentration at SWI (mol/cm3)
S0=35;                                                      %Salinity at SWI

%diffusion coefficients
DC1=Dbio;                                                   %TOC diffusion coefficient (cm2/yr)

qdispO2=348.5750;                                           %O2 diffusion coefficient in water (cm2/yr) 
adispO2=14.0890;                                            %O2 linear coefficient for temperature dependence (cm2/yr/oC)
DO21=(qdispO2+adispO2*T)*dispFactor+Dbio;                   %O2 diffusion coefficient in bioturbated layer (cm2/yr)
DO22=(qdispO2+adispO2*T)*dispFactor;                        %O2 diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispSO4=309.0528;                                          %SO4 diffusion coefficient in water (cm2/yr)
adispSO4=12.2640;                                           %SO4 linear coefficient for temperature dependence (cm2/yr/oC)
DSO41=(qdispSO4+adispSO4*T)*dispFactor+Dbio;                %SO4 diffusion coefficient in bioturbated layer (cm2/yr)
DSO42=(qdispSO4+adispSO4*T)*dispFactor;                     %SO4 diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispH2S=309.0528;                                          %H2S diffusion coefficient in water (cm2/yr)
adispH2S=12.2640;                                           %H2S linear coefficient for temperature dependence (cm2/yr/oC)
DH2S1=(qdispSO4+adispSO4*T)*dispFactor+Dbio;                %H2S diffusion coefficient in bioturbated layer (cm2/yr)
DH2S2=(qdispSO4+adispSO4*T)*dispFactor;                     %H2S diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispNO3=308.4221;                                          %NO3 diffusion coefficient in water (cm2/yr)
adispNO3=12.2640;                                           %NO3 linear coefficient for temperature dependence (cm2/yr/oC)
DN1=(qdispNO3+adispNO3*T)*dispFactor+Dbio;                  %NO3 diffusion coefficient in bioturbated layer (cm2/yr)
DN2=(qdispNO3+adispNO3*T)*dispFactor;                       %NO3 diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispNH4=309.0528;                                          %NH4 diffusion coefficient in water (cm2/yr)
adispNH4=12.2640;                                           %NH4 linear coefficient for temperature dependence (cm2/yr/oC)
DNH41=(qdispNH4+adispNH4*T)*dispFactor+Dbio;                %NH4 diffusion coefficient in bioturbated layer (cm2/yr)
DNH42=(qdispNH4+adispNH4*T)*dispFactor;                     %NH4 diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispDIC=309.0528;                                          %DIC diffusion coefficient in water (cm2/yr)
adispDIC=12.2640;                                           %DIC linear coefficient for temperature dependence (cm2/yr/oC)
DDIC1=(qdispO2+adispDIC*T)*dispFactor+Dbio;                 %DIC diffusion coefficient in bioturbated layer (cm2/yr)
DDIC2=(qdispO2+adispDIC*T)*dispFactor;                      %DIC diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispALK=309.0528;                                          %ALK diffusion coefficient in water (cm2/yr)
adispALK=12.2640;                                           %ALK linear coefficient for temperature dependence (cm2/yr/oC)
DALK1=(qdispALK+adispALK*T)*dispFactor+Dbio;                %ALK diffusion coefficient in bioturbated layer (cm2/yr)
DALK2=(qdispALK+adispALK*T)*dispFactor;                     %ALK diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispS=348.5750;                                            %S diffusion coefficient in water (cm2/yr) 
adispS=14.0890;                                             %S linear coefficient for temperature dependence (cm2/yr/oC)
DS1=(qdispS+adispS*T)*dispFactor+Dbio;                      %S diffusion coefficient in bioturbated layer (cm2/yr)
DS2=(qdispS+adispS*T)*dispFactor;                           %S diffusion coefficient in non-bioturbated layer (cm2/yr)

qdispPO4=309.0528;                                           %PO4 diffusion coefficient in water (cm2/yr)
adispPO4=12.2640;                                            %PO4 linear coefficient for temperature dependence (cm2/yr/oC)
DPO41=(qdispPO4+adispPO4*T)*dispFactor+Dbio;                 %PO4 diffusion coefficient in bioturbated layer (cm2/yr)
DPO42=(qdispPO4+adispPO4*T)*dispFactor;                      %PO4 diffusion coefficient in non-bioturbated layer (cm2/yr)


%rate constants
k1=0.01;                                                    %TOC degradation rate constnat (1/yr)
k2=0.001;                                                   %TOC degradation rate constant (1/yr)

KPO41=10.0;                                                 %Adsorption coefficient in oxic layer (-)
KPO42=1.3;                                                  %Adsorption coefficient in anoxic layer (-)
ksPO4=0.5*365;                                              %Rate constant for kinetic PO4 sorption (1/yr)
PO4s=1.5e-9;                                                %Equilibrium concentration for P sorption (mol/cm3)       
kaPO4=0.004*365;                                            %Rate constant for authigenic P formation (1/yr)
PO4a=0.7e-9;                                                %Equilibrium concentration for authigenic P formation (mol/cm3)
kmPO4=0.0005*365;                                           %Rate constant for Fe-bound P release upon Fe oxide reduction

FePFlux=0.01/1000;                                          %mol/m2/hr     Flux to the surface
FePdeepConc=1000e-9;                                        %Asymptotic concentration of FeP
FeSCt=FePdeepConc*(1.-por);                                 %convert FePdeepConc from /solid to /bulk

NH4ads=1.3;                                                 %NH4 Adsorption coefficient /

%stoichiometric factors
SD=(1-por)/por;                                             %volume factor solid->dissolved phase
OC=1.0*SD;                                                  %O2/C (mol/mol)
NC1=0.1509*SD;                                              %N/C first TOC fraction (mol/mol)
NC2=0.13333*SD;                                             %N/C second TOC fraction (mol/mol)
PC1=0.0094*SD;                                              %P/C first TOC fraction (mol/mol)
PC2=0.0094*SD;                                              %P/C second TOC fraction (mol/mol)
SO4C=0.5*SD;                                                %SO4/C (mol/mol)
DICC1=1.0*SD;                                               %DIC/C until zSO4 (mol/mol)
DICC2=0.5*SD;                                               %DIC/C below zSO$ (mol/mol)
MC=0.5*SD;                                                  %CH4/C (mol/mol)
gamma=1;                                                    %fraction of NH4 that is oxidised in oxic layer
gammaH2S=0.8;                                               %fraction of H2S that is oxidised in oxic layer
gammaCH4=0.9;                                               %fraction of CH4 that is oxidised at SO4
satSO4=0;                                                   % SO4 saturation
NO3CR=(94.4/106)*SD;                                        % NO3 consumed by Denitrification

% Alkalinity production/consumption

ALKROX=15/106;                                              % Aerobic degradation                     
ALKRNIT=-2;                                                 % Nitrification    
ALKRDEN=93.4/106;                                           % Denitrification
ALKRSUL=15/106;                                             % Sulfato reduction
ALKRH2S=-1;                                                 % H2S oxydation (CHECK THIS VALUE!!!)
ALKRMET=14/106;                                             % Methanogenesis
ALKRAOM=2;                                                  % AOM

