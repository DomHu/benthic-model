% Solve H2S

%____________________________________________________________________________________________________________________       
% Case 0: zox=zbio=zno3=0
%__________________________________________________________________________________________________________________________
if(zno3==0)

%LAYER 1 reactive terms: Sulfato reduction (+)
j=1; ztemp=zso4; ztemp1=0;
reac1=SO4C;
reac2=SO4C;
ktemp=0;
Dtemp=DNH42;
calcterm;

%define exponents
bH2S1=w/DH2S1;
bH2S2=w/DH2S2;

%define integration constants and parameters
AH2S1 = (H2S0*bH2S1*exp(bH2S1*zso4) - (a22*exp(a22*zso4) - bH2S1*exp(bH2S1*zso4))*-term(2,1) - (a21*exp(a21*zso4) - bH2S1*exp(bH2S1*zso4))*-term(1,1))*exp(-bH2S1*zso4)/bH2S1;
BH2S1 = (a21*-term(1,1)*exp(a21*zso4) + a22*-term(2,1)*exp(a22*zso4))*exp(-bH2S1*zso4)/bH2S1;
AH2S2 = (H2S0*bH2S1*exp(bH2S1*zso4) + (((a22 - bH2S1)*exp(a22*zso4) + bH2S1)*exp(bH2S1*zso4) - a22*exp(a22*zso4))*-term(2,1) + (((a21 - bH2S1)*exp(a21*zso4) + bH2S1)*exp(bH2S1*zso4) - a21*exp(a21*zso4))*-term(1,1))*exp(-bH2S1*zso4)/bH2S1;
BH2S2 = 0;

if calcconc==1
    ztemp(1)=zso4; ztemp(2)=zinf;
    Atemp(1)=AH2S1; Atemp(2)=AH2S2; 
    Btemp(1)=BH2S1; Btemp(2)=BH2S2;
    atemp(1)=0; atemp(2)=0;
    btemp(1)=bH2S1; btemp(2)= bH2S2; 
    Qtemp(1:4)=0;
    Dtemp=DH2S1;
    conc0temp=H2S0;
    calconc;
    F_H2S=F_temp;
    H2S=conc;
end

else
    
%____________________________________________________________________________________________________________________       
% Case 1, subcase 1: zox<zbio<zno3<zso4
%__________________________________________________________________________________________________________________________
    if(zox<zbio)     
        if(zbio<=zno3)      
        
%LAYER 1 reactive terms: /

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: /

%LAYER 4 reactive terms: Sulfato reduction (+)
j=4; ztemp=zso4; ztemp1=zno3;
reac1=-SO4C;
reac2=-SO4C;
ktemp=0;
Dtemp=DNH42;
calcterm;

%LAYER 5 reactive terms: /

%define exponents
bH2S1=w/DH2S1;
bH2S2=w/DH2S1;
bH2S3=w/DH2S2;
bH2S4=w/DH2S2;
bH2S5=w/DH2S2;

%%% MODIFICATION: FH2S must be multiplied by (1-gammaH2S) and not gammaH2S

%define integration constants and parameters
AH2S1 = (DH2S1*H2S0*bH2S1*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + (a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*exp(bH2S2*zox + bH2S3*zbio) - (-(1-gammaH2S))*FH2S(zso4)*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1);
BH2S1 = -((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*exp(bH2S2*zox + bH2S3*zbio) - (-(1-gammaH2S))*FH2S(zso4)*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1);
AH2S2 = (DH2S1*H2S0*bH2S1*bH2S2*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + (-(1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + ((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*exp(bH2S3*zbio) + ((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*exp(bH2S3*zbio) - (a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*exp(bH2S3*zbio))*exp(bH2S1*zox))*exp(bH2S2*zox))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2);
BH2S2 = -(a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*exp(-bH2S2*zbio + bH2S3*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S2);
AH2S3 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + ((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio) + ((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S3*zbio) - (a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio))*exp(bH2S1*zox))*exp(bH2S2*zox) + ((a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S1*bH2S1*bH2S2*exp(bH2S2*zbio + bH2S3*zbio) - (a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S2*zbio + bH2S3*zbio) + (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4))*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3); 
BH2S3 = -(a21*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*exp(-bH2S3*zno3 - bH2S4*zso4)/bH2S3;
AH2S4 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio) + ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S3*zbio) - (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio))*exp(bH2S1*zox))*exp(bH2S2*zox) - ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S2*zbio + bH2S3*zbio) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) - ((((bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4))*exp(bH2S3*zno3) - (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S3*zno3 + bH2S4*zno3))*bH2S3 + (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S3*zno3 + bH2S4*zno3) - (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4))*exp(bH2S3*zno3))*exp(bH2S2*zbio) + (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*exp(bH2S2*zbio + bH2S3*zbio))*DH2S1*bH2S1*bH2S2)*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S4 = (a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(-bH2S4*zso4)/bH2S4;
AH2S5 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zox + bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio) + ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S3*zbio) - (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S2*bH2S3*exp(bH2S3*zbio))*exp(bH2S1*zox))*exp(bH2S2*zox) - ((a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*DH2S2*bH2S1*bH2S3*exp(bH2S2*zbio + bH2S3*zbio) - (-(1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zbio + bH2S3*zno3 + bH2S4*zso4) + ((((a21*-term(1,4)*exp(a21*zso4) + a22*-term(2,4)*exp(a22*zso4))*exp(bH2S3*zno3 + bH2S4*zno3) - (bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) + (a22*exp(a22*zso4 + bH2S4*zso4) - bH2S4*exp(a22*zso4 + bH2S4*zso4))*-term(2,4) + (a21*exp(a21*zso4 + bH2S4*zso4) - bH2S4*exp(a21*zso4 + bH2S4*zso4))*-term(1,4))*exp(bH2S3*zno3))*bH2S3 - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S3*zno3 + bH2S4*zno3) + (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4))*exp(bH2S3*zno3))*exp(bH2S2*zbio) - (a21*bH2S4*-term(1,4)*exp(a21*zno3 + bH2S4*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zno3 + bH2S4*zso4) - (a21*bH2S4*-term(1,4)*exp(a21*zso4) + a22*bH2S4*-term(2,4)*exp(a22*zso4))*exp(bH2S4*zno3))*exp(bH2S2*zbio + bH2S3*zbio))*DH2S1*bH2S1*bH2S2)*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zbio - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S5 = 0;

if calcconc==1
    ztemp(1)=zox; ztemp(2)=zbio; ztemp(3)=zno3; ztemp(4)=zso4; ztemp(5)=zinf;
    Atemp(1)=AH2S1; Atemp(2)=AH2S2; Atemp(3)=AH2S3; Atemp(4)=AH2S4; Atemp(5)=AH2S5;
    Btemp(1)=BH2S1; Btemp(2)=BH2S2; Btemp(3)=BH2S3; Btemp(4)=BH2S4; Btemp(5)=BH2S5;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0; atemp(5)=0;
    btemp(1)=bH2S1; btemp(2)= bH2S2; btemp(3)=bH2S3; btemp(4)=bH2S4; btemp(5)=bH2S5;
    Qtemp(1:4)=0;
    Dtemp=DH2S1;
    conc0temp=H2S0;
    calconc;
    F_H2S=F_temp;
    H2S=conc;
end


 else 

%__________________________________________________________________________
%Case 1, subcase 2: zox<zno3 <zbio< zso4
%__________________________________________________________________________

%LAYER 1 reactive terms: /

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: Sulfato reduction (+)
j=3; ztemp=zbio; ztemp1=zno3;
reac1=SO4C;
reac2=SO4C;
ktemp=0;
Dtemp=DNH41;
calcterm;

%LAYER 4 reactive terms: Sulfato reduction (+)
j=4; ztemp=zso4; ztemp1=zbio;
reac1=SO4C;
reac2=SO4C;
ktemp=0;
Dtemp=DNH42;
calcterm;

%LAYER 5 reactive terms: /

%define exponents
bH2S1=w/DH2S1;
bH2S2=w/DH2S1;
bH2S3=w/DSO41;
bH2S4=w/DSO42;
bH2S5=w/DSO42;

AH2S1 = (DH2S1*H2S0*bH2S1*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) + (DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio) - (-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1)*exp(bH2S2*zox) + ((1-gammaH2S))*FH2S(zso4)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1); 
BH2S1 = -((DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio) - (-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1)*exp(bH2S2*zox) + ((1-gammaH2S))*FH2S(zso4)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1);
AH2S2 = (DH2S1*H2S0*bH2S1*bH2S2*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) + ((1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - ((1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - ((-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1*bH2S2 - (DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2 + (((-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S1 - (-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S2)*DH2S1 - (DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S1 + (DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2)*exp(bH2S1*zox))*exp(bH2S2*zox))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2); 
BH2S2 = -(DH2S2*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio) - (-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1)*exp(-bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S2);
AH2S3 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) + ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - ((bH2S3*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1*bH2S2 - (DH2S2*bH2S3*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2 + (((bH2S3*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S1 - (bH2S3*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S2)*DH2S1 - (DH2S2*bH2S3*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S1 + (DH2S2*bH2S3*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2)*exp(bH2S1*zox))*exp(bH2S2*zox) - (((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - (DH2S2*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zbio))*bH2S1*bH2S2 - ((bH2S3*-sum_termexp(3,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - -sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4))*bH2S1*bH2S2 + (bH2S3*-sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - bH2S3*-sum_termdev(3,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4))*bH2S1)*DH2S1 + (DH2S2*bH2S3*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zbio))*bH2S1)*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3);
BH2S3 = (DH2S1*-sum_termdev(3,1)*exp(bH2S4*zso4) - DH2S2*-sum_termdev(4,2)*exp(bH2S4*zso4) + DH2S2*-sum_termdev(4,1)*exp(bH2S4*zbio))*exp(-bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S3);
AH2S4 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) + ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - ((bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1*bH2S2 - (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2 + (((bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S1 - (bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S2)*DH2S1 - (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S1 + (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2)*exp(bH2S1*zox))*exp(bH2S2*zox) - (((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - (DH2S2*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - (DH2S2*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3) - DH2S2*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zbio))*exp(bH2S4*zbio))*bH2S1*bH2S2 + ((bH2S3*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zbio) + bH2S4*-sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) + (bH2S3*bH2S4*-sum_termexp(3,1)*exp(bH2S2*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termexp(4,2)*exp(bH2S2*zno3 + bH2S4*zso4) - (bH2S3*-sum_termexp(3,2)*exp(bH2S2*zno3 + bH2S4*zso4) + -sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S4*zso4))*bH2S4)*exp(bH2S3*zbio))*bH2S1*bH2S2 - (bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4))*bH2S1)*DH2S1 + (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zbio))*bH2S1)*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S4 = -sum_termdev(4,1)*exp(-bH2S4*zso4)/bH2S4;
AH2S5 = (DH2S1*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zox + bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) + ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - ((bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*DH2S1*bH2S2 - (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2 + (((bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S1 - (bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S3*zbio + bH2S4*zso4))*bH2S2)*DH2S1 - (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S1 + (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zbio))*bH2S2)*exp(bH2S1*zox))*exp(bH2S2*zox) - (((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - (DH2S2*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4) - (DH2S2*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3) - DH2S2*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zbio))*exp(bH2S4*zbio))*bH2S1*bH2S2 + ((bH2S3*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zbio) + bH2S4*-sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) + (bH2S3*bH2S4*-sum_termexp(3,1)*exp(bH2S2*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termexp(4,2)*exp(bH2S2*zno3 + bH2S4*zso4) - bH2S3*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S4*zso4) - ((-sum_termexp(3,2)*exp(bH2S4*zso4) - -sum_termexp(4,1)*exp(bH2S4*zso4))*bH2S3*exp(bH2S2*zno3) + -sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S4*zso4))*bH2S4)*exp(bH2S3*zbio))*bH2S1*bH2S2 - (bH2S3*bH2S4*-sum_termdev(3,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - bH2S3*bH2S4*-sum_termdev(3,2)*exp(bH2S2*zno3 + bH2S3*zbio + bH2S4*zso4))*bH2S1)*DH2S1 + (DH2S2*bH2S3*bH2S4*-sum_termdev(4,2)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zso4) - DH2S2*bH2S3*bH2S4*-sum_termdev(4,1)*exp(bH2S2*zno3 + bH2S3*zno3 + bH2S4*zbio))*bH2S1)*exp(bH2S1*zox))*exp(-bH2S1*zox - bH2S2*zno3 - bH2S3*zbio - bH2S4*zso4)/(DH2S1*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S5 = 0;  

if calcconc==1
    ztemp(1)=zox; ztemp(2)=zno3; ztemp(3)=zbio; ztemp(4)=zso4; ztemp(5)=zinf;
    Atemp(1)=AH2S1; Atemp(2)=AH2S2; Atemp(3)=AH2S3; Atemp(4)=AH2S4; Atemp(5)=AH2S5;
    Btemp(1)=BH2S1; Btemp(2)=BH2S2; Btemp(3)=BH2S3; Btemp(4)=BH2S4; Btemp(5)=BH2S5;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0; atemp(5)=0;
    btemp(1)=bH2S1; btemp(2)= bH2S2; btemp(3)=bH2S3; btemp(4)=bH2S4; btemp(5)=bH2S5;
    Qtemp(1:5)=0;
    Dtemp=DH2S1;
    conc0temp=H2S0;
    calconc;
    F_H2S=F_temp;
    H2S=conc;
end

if (zbio<=zox) && (zox<=zno3) && (zno3<=zso4)
%____________________________________________________________________________________________________________________             
%Case 2, subcase 1: zbio<zox<zno3<zso4
%____________________________________________________________________________________________________________________           check='Case 2 zox>zbio'

%LAYER 1 reactive terms: /

%LAYER 2 reactive terms: /

%LAYER 3 reactive terms: /

%LAYER 4 reactive terms: Sulfato reduction (+)
j=4; ztemp=zso4; ztemp1=zno3;
reac1=SO4C;
reac2=SO4C;
ktemp=0;
Dtemp=DNH42;
calcterm;

%LAYER 5 reactive terms: /

%define exponents
bH2S1=w/DSO41;
bH2S2=w/DSO42;
bH2S3=w/DSO42;
bH2S4=w/DSO42;
bH2S5=w/DSO42;

AH2S1 = (DH2S1*H2S0*bH2S1*exp(bH2S1*zbio + bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) + ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2*exp(bH2S3*zox) + ((1-gammaH2S))*FH2S(zso4)*exp(bH2S3*zno3 + bH2S4*zso4))*exp(bH2S2*zbio))*exp(-bH2S1*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1);
BH2S1 = -((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2*exp(bH2S3*zox) + ((1-gammaH2S))*FH2S(zso4)*exp(bH2S3*zno3 + bH2S4*zso4))*exp(-bH2S1*zbio + bH2S2*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*bH2S1); 
AH2S2 = (DH2S1*DH2S2*H2S0*bH2S1*bH2S2*exp(bH2S1*zbio + bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) + ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*exp(bH2S3*zox) + DH2S2*((1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S3*zno3 + bH2S4*zso4) - ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*exp(bH2S3*zox) - DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*exp(bH2S3*zno3 + bH2S4*zso4) - ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S1*bH2S1*exp(bH2S3*zox) - ((1-gammaH2S))*FH2S(zso4)*bH2S2*exp(bH2S3*zno3 + bH2S4*zso4))*DH2S2)*exp(bH2S1*zbio))*exp(bH2S2*zbio))*exp(-bH2S1*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*DH2S2*bH2S1*bH2S2);
BH2S2 = -((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2*exp(bH2S3*zox) + ((1-gammaH2S))*FH2S(zso4)*exp(bH2S3*zno3 + bH2S4*zso4))*exp(-bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S2*bH2S2);
AH2S3 = (DH2S1*DH2S2*H2S0*bH2S1*bH2S2*bH2S3*exp(bH2S1*zbio + bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) - (DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*exp(bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) - ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*bH2S1*bH2S2*exp(bH2S2*zox + bH2S3*zox) - (-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*bH2S1*bH2S3*exp(bH2S2*zox + bH2S3*zox))*DH2S1*DH2S2)*exp(bH2S1*zbio) + ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) + DH2S2*((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S3*zno3 + bH2S4*zso4) - ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) - DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*exp(bH2S3*zno3 + bH2S4*zso4) - ((-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S1*bH2S1*bH2S3*exp(bH2S3*zox) - ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*exp(bH2S3*zno3 + bH2S4*zso4))*DH2S2)*exp(bH2S1*zbio))*exp(bH2S2*zbio))*exp(-bH2S1*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*DH2S2*bH2S1*bH2S2*bH2S3);
BH2S3 = -(-sum_termdev(4,2)*exp(bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S4*zno3))*exp(-bH2S3*zno3 - bH2S4*zso4)/bH2S3;
AH2S4 = (DH2S1*DH2S2*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zbio + bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) - (DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*bH2S4*exp(bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) + ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*bH2S1*bH2S3*exp(bH2S2*zox + bH2S3*zox) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*exp(bH2S2*zox + bH2S3*zox) - (bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zno3) - (bH2S4*-sum_termexp(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - -sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zno3))*bH2S3)*exp(bH2S2*zox))*bH2S1*bH2S2)*DH2S1*DH2S2)*exp(bH2S1*zbio) + ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) + DH2S2*((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) - DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S1*bH2S1*bH2S3*exp(bH2S3*zox) - ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4))*DH2S2)*exp(bH2S1*zbio))*exp(bH2S2*zbio))*exp(-bH2S1*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*DH2S2*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S4 = -sum_termdev(4,1)*exp(-bH2S4*zso4)/bH2S4;
AH2S5 = (DH2S1*DH2S2*H2S0*bH2S1*bH2S2*bH2S3*bH2S4*exp(bH2S1*zbio + bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) - (DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*bH2S4*exp(bH2S2*zox + bH2S3*zno3 + bH2S4*zso4) + ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*bH2S1*bH2S3*exp(bH2S2*zox + bH2S3*zox) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*exp(bH2S2*zox + bH2S3*zox) - (bH2S4*-sum_termdev(4,2)*exp(bH2S3*zno3 + bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zno3) - ((bH2S4*-sum_termexp(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termexp(4,1)*exp(bH2S4*zso4) + -sum_termdev(4,1)*exp(bH2S4*zso4))*exp(bH2S3*zno3) - -sum_termdev(4,1)*exp(bH2S3*zno3 + bH2S4*zno3))*bH2S3)*exp(bH2S2*zox))*bH2S1*bH2S2)*DH2S1*DH2S2)*exp(bH2S1*zbio) + ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) + DH2S2*((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S2^2*bH2S2*bH2S3*exp(bH2S3*zox) - DH2S1*((1-gammaH2S))*FH2S(zso4)*bH2S1*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4) - ((bH2S4*-sum_termdev(4,2)*exp(bH2S4*zso4) - bH2S4*-sum_termdev(4,1)*exp(bH2S4*zno3))*DH2S1*bH2S1*bH2S3*exp(bH2S3*zox) - ((1-gammaH2S))*FH2S(zso4)*bH2S2*bH2S3*bH2S4*exp(bH2S3*zno3 + bH2S4*zso4))*DH2S2)*exp(bH2S1*zbio))*exp(bH2S2*zbio))*exp(-bH2S1*zbio - bH2S2*zox - bH2S3*zno3 - bH2S4*zso4)/(DH2S1*DH2S2*bH2S1*bH2S2*bH2S3*bH2S4);
BH2S5 = 0;

if calcconc==1
    ztemp(1)=zbio; ztemp(2)=zox; ztemp(3)=zno3; ztemp(4)=zso4; ztemp(5)=zinf;
    Atemp(1)=AH2S1; Atemp(2)=AH2S2; Atemp(3)=AH2S3; Atemp(4)=AH2S4; Atemp(5)=AH2S5;
    Btemp(1)=BH2S1; Btemp(2)=BH2S2; Btemp(3)=BH2S3; Btemp(4)=BH2S4; Btemp(5)=BH2S5;
    atemp(1)=0; atemp(2)=0; atemp(3)=0; atemp(4)=0; atemp(5)=0;
    btemp(1)=bH2S1; btemp(2)= bH2S2; btemp(3)=bH2S3; btemp(4)=bH2S4; btemp(5)=bH2S5;
    Qtemp(1:4)=0;
    Dtemp=DH2S1;
    conc0temp=H2S0;
    calconc;
    F_H2S=F_temp;
    H2S=conc;
end


        end
    end
    end
end
